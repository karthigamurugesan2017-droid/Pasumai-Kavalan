# Pasumai Kavalan (Green Guardian)
Code for Communities 2.0 - Track 04: Agricultural Intelligence

Files: index.html (structure), style.css (colors/layout), script.js (features and logic)

## IMPORTANT: how to run (needed for camera and live weather)
Camera works only on https or localhost, so do NOT just double-click the file.
1. Open a terminal in this folder
2. Run:  python -m http.server 8000
3. Open http://localhost:8000 in Chrome
(Or drag the folder to https://app.netlify.com/drop for a free https link.)

## Real AI crop scan (free)
1. Get a free key: https://aistudio.google.com/apikey
2. Paste it in the "Real AI scan" card on the page and press Save.
3. Press "Open camera", point at a leaf, press "Scan now".
The key stays only in your own browser (localStorage). Never put your key inside the code files or share a page with it saved.
Without a key the scan runs in SAMPLE mode (not real).

## Features
- Live camera scan: crop, problem, confidence, severity, organic and chemical cure, dose, spray timing
- Safe fallback: under 70% confidence means no treatment, call officer / Kisan Call Centre 1800-180-1551
- Live weather (Open-Meteo, no key): current temperature, humidity, wind, 3-day rain prediction, ET0
- Weather advice: spray timing, fungal risk, pest alert, fertilizer, harvest, sowing, cyclone alert simulation
- Water advisor using live ET0: ET x Kc x soil - rain, drip vs flood
- Tamil voice for results and daily message (page opens in Tamil)
- Farm health score, IVR simulator, missed call, SMS preview, outbreak alerts, roadmap
- Tamil / English toggle, dark mode

## Tamil voice
Needs a Tamil text-to-speech voice on the device. Android: Settings > Language > Text-to-speech > Google > install Tamil.
Windows: Settings > Time & Language > Speech > add Tamil voice.

## Honest limits
- AI diagnosis is advisory and can be wrong. Dosages are examples, verify with TNAU or an agri officer.
- Outbreak alerts are sample data (needs a backend to be real).
- Weather is a forecast, not an official IMD warning.
