/* Pasumai Kavalan - Service Worker for Offline PWA */
var CACHE = 'pk-v2';
var ASSETS = [
  '/',
  '/index.html',
  '/style.css',
  '/script.js',
  '/manifest.json',
  'https://fonts.googleapis.com/css2?family=Baloo+Thambi+2:wght@600;800&family=Mukta+Malar:wght@400;600;700&display=swap'
];

self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open(CACHE).then(function(c) {
      /* Cache core assets; Google Fonts may fail in offline install — that is fine */
      return Promise.allSettled(
        ASSETS.map(function(url) {
          return c.add(url).catch(function() {});
        })
      );
    }).then(function() { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function(e) {
  e.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(
        keys.filter(function(k) { return k !== CACHE; })
            .map(function(k) { return caches.delete(k); })
      );
    }).then(function() { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function(e) {
  var url = e.request.url;
  /* Always go network-first for API calls */
  if (url.indexOf('open-meteo.com') !== -1 ||
      url.indexOf('generativelanguage.googleapis.com') !== -1 ||
      url.indexOf('data.gov.in') !== -1) {
    e.respondWith(
      fetch(e.request).catch(function() {
        return new Response(JSON.stringify({offline: true}),
          {headers: {'Content-Type': 'application/json'}});
      })
    );
    return;
  }
  /* Cache-first for everything else */
  e.respondWith(
    caches.match(e.request).then(function(cached) {
      return cached || fetch(e.request).then(function(resp) {
        return caches.open(CACHE).then(function(c) {
          if (e.request.method === 'GET' && resp.status === 200) {
            c.put(e.request, resp.clone());
          }
          return resp;
        });
      }).catch(function() {
        /* Return cached index for navigation requests */
        if (e.request.mode === 'navigate') {
          return caches.match('/index.html');
        }
      });
    })
  );
});

/* Handle reminder notifications */
self.addEventListener('notificationclick', function(e) {
  e.notification.close();
  e.waitUntil(
    clients.matchAll({type: 'window'}).then(function(list) {
      if (list.length) return list[0].focus();
      return clients.openWindow('/');
    })
  );
});
