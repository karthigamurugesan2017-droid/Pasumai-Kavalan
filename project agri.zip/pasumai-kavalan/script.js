/* ================================================================
   Pasumai Kavalan – Green Guardian  |  script.js
   All 5 previously-fake features now connected to real backend:
   1. Outbreak alerts  – live DB via /api/outbreak/*
   2. SMS alerts       – real MSG91 via /api/sms/send
   3. IVR result       – logged + SMS via /api/ivr/result
   4. Missed call      – callback SMS via /api/missedcall
   5. Follow-up remind – saved to DB via /api/reminder/set
================================================================ */

/* ─── Backend base URL — same origin since frontend is served by backend ── */
var API = window.location.port === '3001'
  ? 'http://localhost:3001'
  : 'http://localhost:3001'; // always point to backend

/* ─── Core state ───────────────────────────────────────────── */
var L=1,first=1,photo=null,res=null,iv={s:0,a:[]};
var S={crop:'tomato',ac:1,stage:1,soil:1,irr:.9,cyc:0,fu:0,mc:0};

/* ─── Language helper (L=1 → Tamil, L=0 → English) ─────────── */
function t(x){return Array.isArray(x)?x[L]:x}

/* ─── Crop / disease data ───────────────────────────────────── */
var CR={paddy:['Paddy','நெல்','🌾'],tomato:['Tomato','தக்காளி','🍅'],groundnut:['Groundnut','நிலக்கடலை','🥜'],banana:['Banana','வாழை','🍌'],chilli:['Chilli','மிளகாய்','🌶️']};
var KC={paddy:[1.05,1.2,.9],tomato:[.6,1.15,.8],groundnut:[.45,1.15,.6],banana:[.5,1.1,1],chilli:[.6,1.05,.85]};
var TIP={paddy:['Avoid extra urea and evening watering.','அதிக யூரியா, மாலை நீர்ப்பாய்ச்சல் தவிர்க்கவும்.'],tomato:['Water at the base, remove lower infected leaves.','வேரில் நீர் பாய்ச்சவும்; அடி நோய் இலைகளை நீக்கவும்.'],groundnut:['Rotate crops and clear old residue.','பயிர் சுழற்சி செய்யவும்; பழைய கழிவை அகற்றவும்.'],banana:['Keep drainage clear, remove infected leaves.','வடிகால் சுத்தமாக வைக்கவும்; நோய் இலைகளை நீக்கவும்.'],chilli:['Space plants for airflow, scout weekly.','காற்றோட்டத்துக்கு இடைவெளி விடவும்; வாரம் ஒருமுறை பாருங்கள்.']};
var D={
paddy:[['Rice blast','குலை நோய்','b','P. fluorescens 10 g/L','சூடோமோனாஸ் 10 கி/லி','Tricyclazole 0.6 g/L','டிரைசைக்ளசோல் 0.6 கி/லி',500,900],['Brown spot','பழுப்பு புள்ளி','b','Neem seed extract 5%','வேப்பங்கொட்டை சாறு 5%','Mancozeb 2.5 g/L','மேன்கோசெப் 2.5 கி/லி',400,800]],
tomato:[['Early blight','இலை கருகல்','b','Neem oil 3 ml/L','வேப்ப எண்ணெய் 3 மிலி/லி','Mancozeb 2 g/L','மேன்கோசெப் 2 கி/லி',450,850],['Leaf curl','இலை சுருள்','y','Yellow traps + neem oil 3 ml/L','மஞ்சள் பொறி + வேப்ப எண்ணெய்','Ask officer (whitefly)','அதிகாரியிடம் கேளுங்கள்',500,1000],['Powdery mildew','சாம்பல் நோய்','w','Buttermilk 1:10','புளித்த மோர் 1:10','Wettable sulphur 2 g/L','கந்தகத் தூள் 2 கி/லி',300,600]],
groundnut:[['Tikka leaf spot','டிக்கா இலைப்புள்ளி','b','Neem seed extract 5%','வேப்பங்கொட்டை சாறு 5%','Chlorothalonil 2 g/L','குளோரோதலோனில் 2 கி/லி',450,800],['Rust','துரு நோய்','y','Garlic-chilli extract','பூண்டு-மிளகாய் கரைசல்','Tebuconazole 1 ml/L','டெபுகோனசோல் 1 மிலி/லி',400,900]],
banana:[['Sigatoka leaf spot','இலைப்புள்ளி','b','Neem oil 3 ml/L, cut infected leaves','வேப்ப எண்ணெய் 3 மிலி/லி, நோய் இலை நீக்கவும்','Propiconazole 1 ml/L','புரோபிகோனசோல் 1 மிலி/லி',600,1100],['Panama wilt','வாடல் நோய்','y','Trichoderma in soil','மண்ணில் டிரைக்கோடெர்மா','No reliable spray, ask officer','தெளிப்பு பலன் இல்லை, அதிகாரியிடம் கேளுங்கள்',500,0]],
chilli:[['Anthracnose','ஆந்த்ராக்னோஸ்','b','P. fluorescens 10 g/L','சூடோமோனாஸ் 10 கி/லி','Mancozeb 2.5 g/L','மேன்கோசெப் 2.5 கி/லி',450,850],['Leaf curl (thrips)','இலை சுருள்','y','Neem oil 3 ml/L','வேப்ப எண்ணெய் 3 மிலி/லி','Ask officer (thrips)','அதிகாரியிடம் கேளுங்கள்',400,0]]};

/* ─── Weather data (sample; replaced by live Open-Meteo) ───── */
var WX=[{d:['Today','இன்று'],t:34,h:62,r:70,mm:8},{d:['Tomorrow','நாளை'],t:33,h:78,r:15,mm:0},{d:['Day 3','மூன்றாம் நாள்'],t:35,h:80,r:10,mm:0}];

/* ─── Backend status ────────────────────────────────────────── */
var BK={online:false,db:'?',sms:'?'};

function checkBackend(){
  fetch(API+'/api/health')
    .then(function(r){return r.json()})
    .then(function(j){
      BK.online=true; BK.db=j.db; BK.sms=j.sms;
      render();
    })
    .catch(function(){BK.online=false;render();});
}

/* ─── Farmer phone stored in localStorage ───────────────────── */
function getFarmerPhone(){try{return localStorage.getItem('pk_phone')||''}catch(e){return ''}}
function setFarmerPhone(p){try{localStorage.setItem('pk_phone',p)}catch(e){}}

/* ─── Utility ───────────────────────────────────────────────── */
function sd(){return WX.filter(function(w){return w.r<30})[0]}
function spray(){var s=sd(),r=WX[0].r;if(r<30)return t(['Spray today, 6-9 AM.','இன்று காலை 6-9 மணிக்கு தெளிக்கலாம்.']);return t(['Rain chance '+r+'%. Do not spray today.'+(s?' Spray '+s.d[0].toLowerCase()+' at 6-9 AM.':''),'மழை வாய்ப்பு '+r+'%. இன்று தெளிக்க வேண்டாம்.'+(s?' '+s.d[1]+' காலை 6-9 மணிக்கு தெளிக்கவும்.':'')])}
function speak(x,lg){try{speechSynthesis.cancel();var l=(lg||(L?'ta':'en'))==='ta'?'ta-IN':'en-IN',u=new SpeechSynthesisUtterance(x);u.lang=l;var v=speechSynthesis.getVoices().filter(function(y){return y.lang.replace('_','-').toLowerCase().indexOf(l.toLowerCase())===0})[0];if(v)u.voice=v;u.rate=.9;speechSynthesis.speak(u)}catch(e){}}
function set(k,v){S[k]=v;if(k==='crop'){res=null;iv={s:0,a:[]}}render()}
function sec(cls,ic,id,title,body){return '<section class="'+cls+'" id="'+id+'"><div class="w"><div class="sh"><div class="ic">'+ic+'</div><h2>'+t(title)+'</h2></div>'+body+'</div></section>'}
function opt(list,cur){return list.map(function(o){return '<option value="'+o[0]+'"'+(String(cur)===String(o[0])?' selected':'')+'>'+t(o[1])+'</option>'}).join('')}
function esc(x){return String(x==null?'':x).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}
function inL(l,f){var o=L;L=l;try{return f()}finally{L=o}}
function noTa(){try{var v=speechSynthesis.getVoices();return v.length>0&&!v.some(function(x){return /^ta/i.test(x.lang)})}catch(e){return false}}

/* ─── Backend status badge ──────────────────────────────────── */
function bkBadge(){
  if(BK.online){
    return '<span class="tag" style="background:var(--gl);font-size:12px">🟢 '+t(['Backend LIVE','பின்னணி LIVE'])+' | DB: '+BK.db+' | SMS: '+BK.sms+'</span>';
  }
  return '<span class="tag" style="background:var(--rl);font-size:12px">🔴 '+t(['Backend offline – start server','சர்வர் இல்லை – server.js தொடங்கவும்'])+'</span>';
}

/* ─── Hero ──────────────────────────────────────────────────── */
function demoTxt(){return t(['Weather: '+(WXL.live?'LIVE':'sample')+'. Scan: '+(S.key?'real AI':'sample (add Gemini key)')+'. Backend: '+(BK.online?'LIVE':'offline')+'.','வானிலை: '+(WXL.live?'நேரடி':'மாதிரி')+'. ஸ்கேன்: '+(S.key?'நிஜ AI':'மாதிரி')+'. பின்னணி: '+(BK.online?'LIVE':'இல்லை')+'.'])}
function hero(){return '<div class="hero"><div class="w"><h1>'+t(['Show the leaf. Get the cure.','இலையைக் காட்டுங்கள். தீர்வைக் கேளுங்கள்.'])+'</h1><p>'+t(['Disease help, water and spray timing, and phone access for every farmer.','நோய் தீர்வு, தண்ணீர், தெளிப்பு நேரம், எல்லா விவசாயிக்கும் போன் வசதி.'])+'</p><a class="cta a" href="#diagnose">'+t(['Try the demo','டெமோ பாருங்கள்'])+'</a><a class="cta b" href="#phone">'+t(['No smartphone?','ஸ்மார்ட்போன் இல்லையா?'])+'</a></div></div><div class="demo">'+demoTxt()+'</div>';}

/* ─── Farm health score ─────────────────────────────────────── */
function health(){var mh=Math.max.apply(0,WX.map(function(w){return w.h})),hot=WX.some(function(w){return w.t>=35&&w.r<20}),s=100,n=[];
 if(mh>=75){s-=25;n.push(['Fungal risk high: do a preventive spray','பூஞ்சை அபாயம் அதிகம்: தடுப்பு தெளிப்பு'])}
 if(hot){s-=10;n.push(['Hot dry days: check for thrips and mites','வெப்பம்: இலைப்பேன் பாருங்கள்'])}
 if(res&&res.c!=null&&!res.healthy){s-=res.c>=70?20:10;n.push(['Disease found: treat as advised','நோய் கண்டறியப்பட்டது: சிகிச்சை செய்யவும்'])}
 if(S.cyc){s-=40;n.push(['Cyclone alert: protect crop and pumps','புயல் எச்சரிக்கை: பயிர், மோட்டாரை பாதுகாக்கவும்'])}
 s=Math.max(5,s);var c=s>=70?'var(--g)':s>=45?'var(--y)':'var(--r)';
 return '<div class="k"><div class="hs"><div class="ring" style="--p:'+s+';--c:'+c+'"><b>'+s+'</b></div><div><h3>'+t(['Farm health score','பண்ணை ஆரோக்கிய மதிப்பெண்'])+'</h3><div style="color:var(--mu);font-size:14px">'+t(['Combines disease, weather and storm risk into one number.','நோய், வானிலை, புயல் அபாயம் அனைத்தும் ஒரே எண்ணில்.'])+'</div><ul>'+(n.length?n.map(function(x){return '<li>'+t(x)+'</li>'}).join(''):'<li>'+t(['All clear today.','இன்று அனைத்தும் நலம்.'])+'</li>')+'</ul></div></div></div>'}

/* ─── My Farm section ───────────────────────────────────────── */
function farm(){
  var phone=getFarmerPhone();
  var regCard='<div class="k sv" style="margin-top:14px"><h3>📱 '+t(['Register for SMS alerts','SMS எச்சரிக்கை பதிவு'])+'</h3><p style="font-size:14px">'+t(['Enter your phone number to get real SMS alerts for disease, weather and reminders.','உங்கள் போன் எண் கொடுங்கள் – நோய், வானிலை, நினைவூட்டல் SMS கிடைக்கும்.'])+'</p><div class="f"><input id="regPhone" type="tel" placeholder="9876543210" value="'+esc(phone)+'"><input id="regName" type="text" placeholder="'+t(['Your name','உங்கள் பெயர்'])+'"><input id="regVillage" type="text" placeholder="'+t(['Village','கிராமம்'])+'"><button class="btn" onclick="registerFarmer()">'+t(['Register','பதிவு செய்'])+'</button></div><div id="regMsg"></div>'+(phone?'<span class="tag" style="margin-top:8px">✅ '+t(['Registered:','பதிவு:'])+' '+esc(phone)+'</span>':'')+'</div>';
  return sec('sg','🧑‍🌾','farm',['My farm','என் பண்ணை'],health()+bkBadge()+'<div class="k" style="margin-top:14px"><div class="chips">'+Object.keys(CR).map(function(k){return '<button class="chip'+(S.crop===k?' on':'')+'" onclick="set(\'crop\',\''+k+'\')">'+CR[k][2]+' '+t(CR[k])+'</button>'}).join('')+'</div><div class="f"><div><label>'+t(['Land (acres)','நிலம் (ஏக்கர்)'])+'</label><input type="number" min="0.5" step="0.5" value="'+S.ac+'" onchange="set(\'ac\',+this.value||1)"></div><div><label>'+t(['Growth stage','வளர்ச்சி நிலை'])+'</label><select onchange="set(\'stage\',+this.value)">'+opt([[0,['Early','ஆரம்பம்']],[1,['Mid','நடுநிலை']],[2,['Late','இறுதி']]],S.stage)+'</select></div><div><label>'+t(['Soil','மண்'])+'</label><select onchange="set(\'soil\',+this.value)">'+opt([[.9,['Clay','களிமண்']],[1,['Red','செம்மண்']],[1.15,['Sandy','மணல்']]],S.soil)+'</select></div><div><label>'+t(['Irrigation','நீர்ப்பாசனம்'])+'</label><select onchange="set(\'irr\',+this.value)">'+opt([[.9,['Drip','சொட்டு நீர்']],[.6,['Flood','வெள்ளம்']]],S.irr)+'</select></div></div></div>'+regCard)}

/* ─── Register farmer ─── REAL API ─────────────────────────── */
function registerFarmer(){
  var phone=(document.getElementById('regPhone')||{}).value||'';
  var name=(document.getElementById('regName')||{}).value||'';
  var village=(document.getElementById('regVillage')||{}).value||'';
  var msg=document.getElementById('regMsg');
  if(!phone){if(msg)msg.innerHTML='<p style="color:var(--r)">'+t(['Enter phone number','போன் எண் கொடுங்கள்'])+'</p>';return;}
  if(msg)msg.innerHTML='<p>'+t(['Registering...','பதிவு செய்கிறது...'])+'</p>';
  fetch(API+'/api/farmer/register',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({phone,name,village,crop:S.crop,lang:L?'ta':'en'})
  })
  .then(function(r){return r.json()})
  .then(function(j){
    if(j.ok){
      setFarmerPhone(phone);
      if(msg)msg.innerHTML='<p class="tag" style="background:var(--gl)">✅ '+t(['Registered! Welcome SMS sent to ','பதிவு! வரவேற்பு SMS அனுப்பப்பட்டது: '])+phone+'</p>';
      render();
    } else {
      if(msg)msg.innerHTML='<p style="color:var(--r)">'+esc(j.error)+'</p>';
    }
  })
  .catch(function(){
    if(msg)msg.innerHTML='<p style="color:var(--r)">'+t(['Backend offline. Start the server.','சர்வர் இல்லை. server.js தொடங்கவும்.'])+'</p>';
  });
}

/* ─── Disease diagnosis ─────────────────────────────────────── */
function result(){var l=D[S.crop],c=res.c,d=res.list[0].d,low=c<70,h='<div class="k"><h3>'+t(['Possible diseases','சாத்தியமான நோய்கள்'])+'</h3>'+res.list.map(function(x){return '<div class="row"><span>'+t([x.d[0],x.d[1]])+'</span><b>'+x.p+'%</b></div><div class="bar"><i style="width:'+x.p+'%"></i></div>'}).join('')+'<span class="tag" style="background:var(--'+(low?'rl':'gl')+')">'+t(['Confidence','நம்பகத்தன்மை'])+' '+c+'%</span></div>';
 if(low)return h+'<div class="k sr"><h3>⚠ '+t(['Not sure enough','உறுதியாக இல்லை'])+'</h3><p>'+t(['Do not spray yet. Call your agri officer or Kisan Call Centre 1800-180-1551 (toll free).','இப்போது தெளிக்க வேண்டாம். வேளாண் அதிகாரி அல்லது கிசான் அழைப்பு மையம் 1800-180-1551 (இலவசம்) அழைக்கவும்.'])+'</p><a class="btn" href="tel:18001801551" style="text-decoration:none;display:inline-block">📞 1800-180-1551</a></div>';
 var cs=function(a){return a?'Rs '+Math.round(a*S.ac):'-'};
 return h+'<div class="k"><h3>'+t([d[0],d[1]])+'</h3><div class="row"><span>🌿 '+t(['Organic','இயற்கை'])+'</span><b>'+t([d[3],d[4]])+'</b></div><div class="row"><span>🧪 '+t(['Chemical','மருந்து'])+'</span><b>'+t([d[5],d[6]])+'</b></div><div class="row"><span>₹ '+t(['Cost for',''])+' '+S.ac+' '+t(['acre','ஏக்கர்'])+'</span><b>'+cs(d[7])+' / '+cs(d[8])+'</b></div><div class="row"><span>🌦 '+t(['Spray timing','தெளிக்கும் நேரம்'])+'</span><span>'+spray()+'</span></div><div class="row"><span>🛡 '+t(['Prevention','தடுப்பு'])+'</span><span>'+t(TIP[S.crop])+'</span></div><div style="font-size:13px;color:var(--mu)">'+t(['Safety: gloves and mask, keep away from water.','பாதுகாப்பு: கையுறை, முகமூடி; நீர்நிலை அருகில் தெளிக்க வேண்டாம்.'])+'</div><button class="btn" onclick="speak(this.dataset.s)" data-s="'+(t([d[0],d[1]])+'. '+t(['Organic: ','இயற்கை: '])+t([d[3],d[4]])+'. '+spray()).replace(/"/g,'')+'">🔊 '+t(['Listen','குரலில் கேளுங்கள்'])+'</button> <button class="btn l" onclick="setReminder(\''+t([d[0],d[1]])+'\',\''+t([d[1],d[1]])+'\')">⏰ '+t(['Remind in 5 days','5 நாளில் நினைவூட்டு'])+'</button><div id="reminderMsg"></div>'+(S.fu?'<p class="tag" style="margin-top:10px;background:var(--gl)">✅ '+t(['Reminder saved to server. SMS will come in 5 days.','நினைவூட்டல் சேர்க்கப்பட்டது. 5 நாளில் SMS வரும்.'])+'</p>':'')+'</div>'}

/* ─── Follow-up Reminder ─── REAL API (was memory flag) ────── */
function setReminder(disease,disease_ta){
  var phone=getFarmerPhone();
  var msgEl=document.getElementById('reminderMsg');
  if(!phone){
    if(msgEl)msgEl.innerHTML='<p class="tag" style="background:var(--yl);margin-top:8px">'+t(['Register your phone number above to get a real SMS reminder.','மேலே போன் எண் பதிவு செய்தால் உண்மையான SMS வரும்.'])+'</p>';
    S.fu=1;render();return;
  }
  if(msgEl)msgEl.innerHTML='<p style="font-size:13px">'+t(['Saving reminder...','நினைவூட்டல் சேமிக்கிறது...'])+'</p>';
  fetch(API+'/api/reminder/set',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({phone,disease,disease_ta,crop:S.crop,daysLater:5})
  })
  .then(function(r){return r.json()})
  .then(function(j){
    S.fu=1;
    var d=new Date(j.followUpDate);
    var dateStr=d.toLocaleDateString('en-IN',{day:'numeric',month:'short'});
    if(msgEl)msgEl.innerHTML='<p class="tag" style="background:var(--gl);margin-top:8px">✅ '+t(['Reminder saved! SMS on ','நினைவூட்டல் சேமிக்கப்பட்டது! SMS: '])+dateStr+'</p>';
    render();
  })
  .catch(function(){
    S.fu=1; // fallback to memory flag
    if(msgEl)msgEl.innerHTML='<p class="tag" style="background:var(--yl);margin-top:8px">'+t(['Backend offline – reminder set locally only.','சர்வர் இல்லை – உள்ளூரில் மட்டும் சேமிக்கப்பட்டது.'])+'</p>';
    render();
  });
}

function diag(){var b='<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))"><div class="k">'+camBlock()+'<label>'+t(['Or upload a leaf photo','அல்லது இலை படம் பதிவேற்றவும்'])+' ('+CR[S.crop][2]+')</label><input type="file" accept="image/*" capture="environment" onchange="onPhoto(this)">'+(photo?'<img class="pv" src="'+photo.src+'"><button class="btn" onclick="analyze()">'+t(['Diagnose','கண்டறி'])+'</button>':'')+(res&&res.bad?'<p class="tag" style="background:var(--rl);margin-top:10px">'+t(['Photo too dark or blurry. Retake in daylight.','படம் இருட்டாக உள்ளது. வெளிச்சத்தில் மீண்டும் எடுக்கவும்.'])+'</p>':'')+'</div><div>'+(res&&res.loading?loadCard():res&&res.err?errCard():res&&res.ai?resultAI():res&&res.list?result():'')+'</div></div>'+keyCard();return sec('sg','🔬','diagnose',['Disease diagnosis','நோய் கண்டறிதல்'],b)}
function onPhoto(el){var f=el.files[0];if(!f)return;var im=new Image();im.onload=function(){photo={src:im.src,size:f.size,img:im};res=null;S.fu=0;render();location.hash='#diagnose'};im.src=URL.createObjectURL(f)}
function run(){var c=document.createElement('canvas');c.width=c.height=40;var x=c.getContext('2d');x.drawImage(photo.img,0,0,40,40);var d=x.getImageData(0,0,40,40).data,s=0;for(var i=0;i<d.length;i+=4)s+=(d[i]+d[i+1]+d[i+2])/3;s/=1600;if(s<45||s>235){res={bad:1};render();return}
 var l=D[S.crop],sd=photo.size%100,c0=52+sd%43,a=l[sd%l.length],rest=l.filter(function(y){return y!==a}),list=[{d:a,p:c0}],left=100-c0;rest.forEach(function(y,i){var p=i===rest.length-1?left:Math.round(left*.65);list.push({d:y,p:p});left-=p});res={list:list,c:c0};render();}

/* ─── Water advisor ─────────────────────────────────────────── */
function wcalc(){var kc=KC[S.crop][S.stage],mm=Math.max(0,(WX[0].et||5.2)*kc*S.soil-WX[0].mm),b=mm*4047*S.ac,r=function(v){return Math.round(v/100)*100};return {kc:kc,mm:mm,use:r(b/S.irr),drip:r(b/.9),flood:r(b/.6)}}
function water(){var w=wcalc(),m=w.use===0?t(['Rain covers the crop today. No irrigation needed.','இன்று மழை போதும். தண்ணீர் தேவையில்லை.']):t(['Give about '+w.use+' litres for '+S.ac+' acre today, in the morning.','இன்று '+S.ac+' ஏக்கருக்கு சுமார் '+w.use+' லிட்டர் தண்ணீர் காலையில் பாய்ச்சவும்.']);
 var b='<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))"><div class="k"><h3>'+t(['Water need today','இன்றைய தண்ணீர் தேவை'])+'</h3><div class="row"><span>ET0</span><b>'+(WX[0].et||5.2).toFixed(1)+' mm</b></div><div class="row"><span>Kc</span><b>'+w.kc+'</b></div><div class="row"><span>'+t(['Rain today','இன்றைய மழை'])+'</span><b>'+WX[0].mm+' mm</b></div><div class="row"><span>'+t(['Water to apply','பாய்ச்ச வேண்டியது'])+'</span><b>'+w.use.toLocaleString('en-IN')+' L</b></div><p>'+m+'</p><button class="btn" onclick="speak(this.dataset.s)" data-s="'+m.replace(/"/g,'')+'">🔊 '+t(['Listen','குரலில் கேளுங்கள்'])+'</button><div style="font-size:13px;color:var(--mu);margin-top:8px">ET × Kc × soil − rain ÷ efficiency. 1 mm on 1 acre = 4,047 L.</div></div><div class="k"><h3>'+t(['Drip vs flood','சொட்டு vs வெள்ளம்'])+'</h3><div class="row"><span>💧 '+t(['Drip','சொட்டு'])+'</span><b>'+w.drip.toLocaleString('en-IN')+' L</b></div><div class="bar"><i style="width:'+(w.flood?Math.round(w.drip/w.flood*100):0)+'%"></i></div><div class="row"><span>🌊 '+t(['Flood','வெள்ளம்'])+'</span><b>'+w.flood.toLocaleString('en-IN')+' L</b></div><div class="bar"><i style="width:100%"></i></div><p><b>'+t(['Drip saves ','சொட்டு நீர் சேமிப்பு '])+(w.flood-w.drip).toLocaleString('en-IN')+' L</b></p></div></div>';return sec('sb','💧','water',['Water advisor','தண்ணீர் ஆலோசனை'],b)}

/* ─── Weather ───────────────────────────────────────────────── */
function wx(){var mh=Math.max.apply(0,WX.map(function(w){return w.h})),hot=WX.some(function(w){return w.t>=35&&w.r<20}),rain=WX.some(function(w){return w.r>=60}),C=[
[['Spray timing','தெளிக்கும் நேரம்'],spray(),WX[0].r>=30?'r':'g'],
[['Fungal disease risk','பூஞ்சை நோய் அபாயம்'],mh>=75?t(['Humidity '+mh+'% ahead. Do a preventive spray.','ஈரப்பதம் '+mh+'%. தடுப்பு தெளிப்பு செய்யவும்.']):t(['Low risk for now.','இப்போது அபாயம் குறைவு.']),mh>=75?'r':'g'],
[['Pest alert','பூச்சி எச்சரிக்கை'],hot?t(['Hot dry days. Check leaf undersides for thrips.','வெப்பம். இலை அடியில் இலைப்பேன் பாருங்கள்.']):t(['No pest signal.','பூச்சி அறிகுறி இல்லை.']),hot?'y':'g'],
[['Fertilizer','உரம்'],WX[0].r>=50?t(['Hold urea. Rain will wash it.','இன்று உரம் இட வேண்டாம்.']):t(['Fine to apply.','இடலாம்.']),WX[0].r>=50?'y':'g'],
[['Harvest','அறுவடை'],rain?t(['Rain in 3 days. Harvest early.','3 நாளில் மழை. முன்பே அறுவடை செய்யுங்கள்.']):t(['No rain threat.','மழை அச்சம் இல்லை.']),rain?'y':'g'],
[['Sowing','விதைப்பு'],WX[0].r>=60?t(['Good soil moisture. Sow after 2 days.','மண் ஈரம் நல்லது. 2 நாள் பின் விதைக்கவும்.']):t(['Wait for rain.','மழைக்கு காத்திருக்கவும்.']),'b']];
 var b=wxBar()+'<div class="grid">'+C.map(function(c){return '<div class="k s'+c[2]+'"><h3>'+t(c[0])+'</h3><p>'+c[1]+'</p></div>'}).join('')+'</div><div class="k" style="margin-top:18px"><div class="grid" style="grid-template-columns:repeat(3,1fr);gap:8px;text-align:center">'+WX.map(function(w){return '<div class="wc"><b>'+t(w.d)+'</b>'+w.t+'°C<br>💧'+w.h+'% ☔'+w.r+'%</div>'}).join('')+'</div><h3 style="margin-top:14px">'+t(['Daily message','தினசரி செய்தி'])+'</h3><p id="dm">'+t(['Vanakkam! Today '+WX[0].t+'°C, rain chance '+WX[0].r+'%. Water: '+wcalc().use+' L. Spray: '+spray(),'வணக்கம்! இன்று '+WX[0].t+'°C, மழை வாய்ப்பு '+WX[0].r+'%. தண்ணீர்: '+wcalc().use+' லிட்டர். '+spray()])+'</p><button class="btn" onclick="speak(document.getElementById(\'dm\').textContent)">🔊 '+t(['Listen','குரலில் கேளுங்கள்'])+'</button> <button class="btn l" onclick="set(\'cyc\','+(S.cyc?0:1)+')">🌀 '+t(['Simulate cyclone','புயல் சோதனை'])+'</button>'+(S.cyc?'<div class="k sr" style="margin:14px 0 0"><h3>🌀 '+t(['Cyclone warning','புயல் எச்சரிக்கை'])+'</h3><p>'+t(['Heavy rain and strong winds in 24 hours. Harvest, open drains, secure pumps.','24 மணி நேரத்தில் கனமழை. முதிர்ந்த பயிரை அறுவடை செய்யுங்கள், வடிகால் திறக்கவும்.'])+'</p></div>':'')+'</div>';return sec('sy','⛅','weather',['Weather advice','வானிலை ஆலோசனை'],b)}

/* ─── IVR ─── REAL API (was UI-only) ───────────────────────── */
var CK=['paddy','tomato','groundnut','banana','chilli'];
function ivrRes(){var cr=CK[iv.a[0]-1],sp=['y','b','w'][iv.a[1]-1],wl=iv.a[2]===1,m=sp&&D[cr]&&D[cr].filter(function(x){return x[2]===sp})[0];
 if(!m||wl)return t(['Not sure enough. Please call: 1800-180-1551. Do not spray yet.','உறுதியாக இல்லை. 1800-180-1551 அழைக்கவும். தெளிக்க வேண்டாம்.']);
 return t([m[0]+'. Use '+m[3]+'. Spray 6 AM morning.',m[1]+'. '+m[4]+' பயன்படுத்தவும். காலை 6 மணிக்கு தெளிக்கவும்.'])}

function ivrScr(){
 var P=[['Welcome! Your crop? 1 Paddy 2 Tomato 3 Groundnut 4 Banana 5 Chilli','வணக்கம்! பயிர்? 1 நெல் 2 தக்காளி 3 கடலை 4 வாழை 5 மிளகாய்'],['Leaf spots? 1 Yellow 2 Brown/Black 3 White powder 4 Not sure','இலையில்? 1 மஞ்சள் 2 கருப்பு/பழுப்பு 3 வெள்ளைப்பொடி 4 தெரியவில்லை'],['Leaves drooping? 1 Yes 2 No','இலை வாடுகிறதா? 1 ஆம் 2 இல்லை']],n=[5,4,2];
 if(iv.s>2){
   var advice=ivrRes();
   // Log and send SMS via backend
   logIVR(advice);
   return '<div>🔊 '+advice+'</div><button class="btn" style="background:var(--v)" onclick="iv={s:0,a:[]};render()">↺ '+t(['Call again','மீண்டும்'])+'</button> <button class="btn l" onclick="speak(this.dataset.s)" data-s="'+advice.replace(/"/g,'')+'">🔊 '+t(['Listen','கேளு'])+'</button>';
 }
 var k='';for(var i=1;i<=n[iv.s];i++)k+='<button onclick="iv.a.push('+i+');iv.s++;render()">'+i+'</button>';
 return '<div>🔊 '+t(P[iv.s])+'</div><div class="keys">'+k+'</div>'
}

function logIVR(advice){
 var phone=getFarmerPhone();
 if(!BK.online) return; // silently skip if backend offline
 fetch(API+'/api/ivr/result',{
   method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({
     phone: phone||'unknown',
     crop: CK[iv.a[0]-1]||S.crop,
     symptoms: ['yellow','brown','white','unsure'][iv.a[1]-1]||'',
     result: advice,
     callType: 'ivr'
   })
 }).catch(function(){});
}

/* ─── Missed Call ─── REAL API (was UI-only) ───────────────── */
function doMissedCall(){
 var phone=getFarmerPhone();
 var msgEl=document.getElementById('mcMsg');
 if(!phone){
   S.mc=1;render();
   if(msgEl)msgEl.innerHTML='<p class="tag" style="background:var(--yl)">'+t(['Register phone above to get a real SMS callback.','மேலே போன் எண் பதிவு செய்தால் உண்மையான SMS வரும்.'])+'</p>';
   return;
 }
 if(msgEl)msgEl.innerHTML='<p>'+t(['Sending callback SMS...','SMS அனுப்புகிறது...'])+'</p>';
 fetch(API+'/api/missedcall',{
   method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({phone, crop:S.crop})
 })
 .then(function(r){return r.json()})
 .then(function(j){
   S.mc=1;
   if(msgEl)msgEl.innerHTML='<p class="tag" style="background:var(--gl)">✅ '+t(['Callback SMS sent to ','SMS அனுப்பப்பட்டது: '])+phone+'<br><small>'+esc(j.preview||'')+'</small></p>';
   render();
 })
 .catch(function(){
   S.mc=1;render();
   if(msgEl)msgEl.innerHTML='<p class="tag" style="background:var(--yl)">'+t(['Backend offline. SMS not sent.','சர்வர் இல்லை. SMS அனுப்பவில்லை.'])+'</p>';
 });
}

/* ─── SMS Send UI ─── REAL API ──────────────────────────────── */
function sendManualSMS(){
 var phone=(document.getElementById('smsPhone')||{}).value||getFarmerPhone()||'';
 var msg=(document.getElementById('smsMsg')||{}).value||'';
 var el=document.getElementById('smsSendResult');
 if(!phone||!msg){if(el)el.innerHTML='<p style="color:var(--r)">'+t(['Enter phone and message.','போன் எண் மற்றும் செய்தி கொடுங்கள்.'])+'</p>';return;}
 if(el)el.innerHTML='<p>'+t(['Sending...','அனுப்புகிறது...'])+'</p>';
 fetch(API+'/api/sms/send',{
   method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({phone,message:msg,type:'manual'})
 })
 .then(function(r){return r.json()})
 .then(function(j){
   if(el)el.innerHTML='<p class="tag" style="background:var(--gl)">✅ '+t(['SMS status: ','SMS நிலை: '])+esc(j.result&&j.result.status||'sent')+'</p>';
 })
 .catch(function(){
   if(el)el.innerHTML='<p class="tag" style="background:var(--rl)">'+t(['Backend offline.','சர்வர் இல்லை.'])+'</p>';
 });
}

/* ─── Phone section with REAL IVR + Missed Call ────────────── */
function phone(){
 var ch=[['🧑‍🌾',['Village volunteer','கிராம தன்னார்வலர்'],'One smartphone per village. Farmer shows the leaf, volunteer sends the photo.'],['📞',['Toll-free IVR','இலவச IVR'],'Button phone call, 3 questions. No photo needed. Result SMS to registered phone.'],['📴',['Missed call','மிஸ்டு கால்'],'Farmer misses a call → real SMS callback sent to registered phone.'],['💬',['Tamil SMS','தமிழ் SMS'],'Daily weather, spray and outbreak alerts via MSG91.'],['🏪',['Kiosk at FPO','FPO கியோஸ்க்'],'Shared tablet at the FPO or cooperative.'],['📻',['Community radio','சமுதாய வானொலி'],'Village-level alerts for farmers without a phone.']],c=['sv','sp','sy','sb','sg','sr'];
 var smsPanel='<div class="k" style="margin-top:14px"><h3>💬 '+t(['Send a test SMS','சோதனை SMS அனுப்பு'])+'</h3><p style="font-size:13px">'+bkBadge()+'</p><div class="f"><input id="smsPhone" type="tel" placeholder="9876543210" value="'+esc(getFarmerPhone())+'"><input id="smsMsg" type="text" placeholder="'+t(['Type SMS message here','SMS செய்தி இங்கே'])+'"><button class="btn" onclick="sendManualSMS()">'+t(['Send','அனுப்பு'])+'</button></div><div id="smsSendResult"></div></div>';
 var b='<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))"><div class="k"><h3>'+t(['Try the IVR call','IVR அழைப்பை முயற்சி'])+'</h3><p style="font-size:14px">'+t(['Press keys like a button phone. Result SMS sent to your registered number.','பட்டன் போன் போல அழுத்துங்கள். முடிவு உங்கள் பதிவு எண்ணுக்கு SMS போகும்.'])+'</p><div class="ivr">'+ivrScr()+'</div><button class="btn l" onclick="doMissedCall()">📴 '+t(['Give a missed call','மிஸ்டு கால்'])+'</button><div id="mcMsg"></div></div>'+smsPanel+'<div class="grid" style="grid-template-columns:1fr 1fr;gap:12px">'+ch.map(function(x,i){return '<div class="k '+c[i]+'" style="padding:12px"><div style="font-size:26px">'+x[0]+'</div><h3 style="font-size:17px">'+t(x[1])+'</h3><div style="font-size:13px;color:var(--mu)">'+x[2]+'</div></div>'}).join('')+'</div></div>';
 return sec('sv','📞','phone',['No smartphone? No problem','ஸ்மார்ட்போன் இல்லையா? பரவாயில்லை'],b)}

/* ─── Outbreak alerts ─── REAL API (was 3 hardcoded) ───────── */
var LIVE_OUTBREAKS=null;

function loadOutbreaks(){
 fetch(API+'/api/outbreak/list')
   .then(function(r){return r.json()})
   .then(function(j){
     LIVE_OUTBREAKS=j.outbreaks||[];
     render();
   })
   .catch(function(){LIVE_OUTBREAKS=null;});
}

function reportOutbreak(){
 var phone=getFarmerPhone();
 if(!res||!res.list) return;
 var disease=res.list[0].d[0], disease_ta=res.list[0].d[1];
 var el=document.getElementById('reportMsg');
 if(el)el.innerHTML='<p>'+t(['Reporting...','அறிக்கை அனுப்புகிறது...'])+'</p>';
 fetch(API+'/api/outbreak/report',{
   method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({village: (typeof WXL!=='undefined'&&WXL.name)||'My Village', crop:S.crop, disease, disease_ta, reportedBy:phone||'anonymous'})
 })
 .then(function(r){return r.json()})
 .then(function(j){
   if(el)el.innerHTML='<p class="tag" style="background:var(--gl)">✅ '+t(['Reported! Cases: ','அறிக்கை! நிகழ்வுகள்: '])+j.record.cases+(j.record.cases>=3?' ⚠️ '+t(['Alerts sent to nearby farmers!','அருகில் உள்ள விவசாயிகளுக்கு எச்சரிக்கை!']):'')+'</p>';
   loadOutbreaks();
 })
 .catch(function(){
   if(el)el.innerHTML='<p class="tag" style="background:var(--yl)">'+t(['Backend offline. Could not report.','சர்வர் இல்லை.'])+'</p>';
 });
}

function alerts(){
 var rows=LIVE_OUTBREAKS||getSampleOutbreaks();
 var source=LIVE_OUTBREAKS?'<span class="tag" style="background:var(--gl);font-size:12px">🟢 '+t(['Live from database','நேரடி தரவுத்தளம்'])+'</span>':'<span class="tag" style="background:var(--yl);font-size:12px">🟡 '+t(['Sample data – backend offline','மாதிரி – சர்வர் இல்லை'])+'</span>';
 var reportBtn=(res&&res.list&&res.c>=70)?'<button class="btn" onclick="reportOutbreak()">📢 '+t(['Report this disease in my village','என் கிராமத்தில் இந்த நோயை அறிக்கையிடு'])+'</button><div id="reportMsg"></div>':'<p style="font-size:13px;color:var(--mu)">'+t(['Diagnose a crop first to report an outbreak.','முதலில் நோயை கண்டறியுங்கள்.'])+'</p>';
 var b='<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))"><div class="k"><h3>'+t(['Village outbreak alerts','கிராம நோய் எச்சரிக்கை'])+'</h3>'+source+rows.map(function(o){var hi=(o.cases||0)>=3;return '<div class="row" style="margin-top:10px"><span>'+esc(o.village)+' '+( CR[o.crop]?CR[o.crop][2]:'')+'<br><small>'+esc(t([o.disease,o.disease_ta||o.disease]))+', '+o.cases+' '+t(['cases','நிகழ்வுகள்'])+'</small></span><span class="tag" style="background:var(--'+(hi?'rl':'gl')+')">'+(hi?t(['ALERT','எச்சரிக்கை']):t(['Watch','கவனிக்க']))+'</span></div>'}).join('')+'<p style="font-size:13px;margin-top:12px">'+t(['3+ cases in an area triggers SMS alerts to all registered farmers nearby.','3+ நிகழ்வுகள் இருந்தால் அருகிலுள்ள விவசாயிகளுக்கு SMS எச்சரிக்கை போகும்.'])+'</p>'+reportBtn+'</div><div class="k"><h3>'+t(['SMS preview','SMS மாதிரி'])+'</h3><div class="phone" style="box-shadow:4px 4px 0 var(--p)"><div class="bub bot" style="opacity:1">'+spray()+'</div><div class="bub bot" style="opacity:1">'+t(['Blast disease spreading in Thirumangalam. Preventive spray advised. 1800-180-1551.','திருமங்கலத்தில் குலை நோய் பரவுகிறது. தடுப்பு தெளிப்பு செய்யவும். 1800-180-1551.'])+'</div></div><p style="font-size:13px;color:var(--mu)">'+t(['Real SMS sent via MSG91. Simulated if no API key set.','MSG91 வழியாக உண்மையான SMS. API key இல்லாவிட்டால் simulation.'])+'</p></div></div>';
 return sec('sr','🚨','alerts',['Community alerts','சமுதாய எச்சரிக்கை'],b)}

function getSampleOutbreaks(){
 return [{village:'Melur',crop:'tomato',disease:'Early blight',disease_ta:'இலை கருகல்',cases:5},{village:'Thirumangalam',crop:'paddy',disease:'Rice blast',disease_ta:'குலை நோய்',cases:4},{village:'Usilampatti',crop:'groundnut',disease:'Tikka leaf spot',disease_ta:'டிக்கா இலைப்புள்ளி',cases:2}];
}

/* ─── Roadmap ───────────────────────────────────────────────── */
function road(){var P=[['Pilot','சோதனை','1-2 villages with a KVK or agri officer. Collect 100 real photos.'],['Partner','கூட்டாண்மை','TNAU, agri department and FPOs validate every piece of advice.'],['Scale','விரிவாக்கம்','Train Krishi Sakhi volunteers, add IVR and missed call.'],['Sustain','நிலைத்தன்மை','Free for farmers. CSR, NGO and government grants fund it.']],c=['sg','sb','sv','sy'];
 var b='<div class="steps">'+P.map(function(p,i){return '<div class="k '+c[i]+'"><h3>'+t([p[0],p[1]])+'</h3><div>'+p[2]+'</div></div>'}).join('')+'</div><div class="chips">'+['Real SMS alerts (MSG91)','MongoDB outbreak DB','Follow-up reminders','IVR call logging','Farmer registration','Offline PWA (service worker)'].map(function(x){return '<span class="tag" style="font-size:14px;padding:5px 14px">✅ '+x+'</span>'}).join('')+'</div>';return sec('sp','🚀','roadmap',['Real-world plan','நடைமுறை திட்டம்'],b)}

/* ─── Main render ───────────────────────────────────────────── */
function render(){
 document.getElementById('brand').innerHTML='🌾 '+(L?'பசுமை <span>காவலன்</span>':'Pasumai <span>Kavalan</span>');
 document.getElementById('lb').textContent=L?'English':'தமிழ்';
 document.getElementById('nav').innerHTML=[
   ['#diagnose','g',['Diagnose','நோய்']],
   ['#water','b',['Water','தண்ணீர்']],
   ['#weather','y',['Weather','வானிலை']],
   ['#stress','r',['Stress Alert','ஆரம்ப எச்சரிக்கை']],
   ['#resistance','v',['Resistance','எதிர்ப்பு']],
   ['#progress','p',['Leaf Track','இலை நடை']],
   ['#phone','v',['No phone','போன்']],
   ['#alerts','r',['Alerts','எச்சரிக்கை']],
   ['#roadmap','p',['Plan','திட்டம்']]
 ].map(function(x){return '<a href="'+x[0]+'" style="background:var(--'+x[1]+');'+(x[1]==='y'?'color:#14231a':'')+'">'+t(x[2])+'</a>'}).join('');
 document.getElementById('root').innerHTML=
   hero()+farm()+diag()+water()+wx()+
   stressSection()+resistanceSection()+progressSection()+
   phone()+alerts()+road()+
   '<footer><div class="w">'+t(['Keeladi to AI: technology for Tamil Nadu farming roots.','கீழடி முதல் AI வரை: தமிழ் மண்ணின் வேளாண் மரபுக்கு AI துணை.'])+'</div></footer>';
 first=0;reattach();
}

/* ===== LIVE FEATURES: camera, Gemini AI, live weather ======= */
try{S.key=localStorage.getItem('gk')||''}catch(e){S.key=''}
S.city='Madurai';S.model='gemini-2.5-flash';
var stream=null,camOn=0,WXL={live:0,name:'',now:null,busy:0,fail:0},SP={ta:'',en:''};
var LOC={'Madurai':[9.92,78.12],'Chidambaram':[11.4,79.69],'Coimbatore':[11.0,76.96],'Thanjavur':[10.79,79.14],'Salem':[11.66,78.15],'Tirunelveli':[8.71,77.76]};

function noTa(){try{var v=speechSynthesis.getVoices();return v.length>0&&!v.some(function(x){return /^ta/i.test(x.lang)})}catch(e){return false}}

/* camera */
function camBlock(){return '<h3>📷 '+t(['Live crop scan','நேரடி பயிர் ஸ்கேன்'])+'</h3>'+(camOn?'<video id="cam" class="pv" autoplay playsinline muted></video><button class="btn" onclick="scan()">🔍 '+t(['Scan now','ஸ்கேன் செய்'])+'</button> <button class="btn l" onclick="camStop()">'+t(['Stop','நிறுத்து'])+'</button>':'<button class="btn" onclick="camStart()">📷 '+t(['Open camera','கேமரா திற'])+'</button>')+(S.err?'<p class="tag" style="background:var(--rl);margin-top:10px">'+esc(S.err)+'</p>':'')+'<div style="font-size:13px;color:var(--mu);margin:6px 0 10px">'+t(['Point at one leaf in daylight and tap Scan.','ஒரு இலையை வெளிச்சத்தில் காட்டி ஸ்கேன் அழுத்தவும்.'])+'</div>'}
function camStart(){S.err='';if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){S.err=t(['Camera needs https or localhost.','கேமராவுக்கு https தேவை.']);render();return}navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false}).then(function(m){stream=m;camOn=1;render()}).catch(function(){S.err=t(['Camera blocked. Allow permission.','கேமரா தடுக்கப்பட்டது.']);render()})}
function camStop(){if(stream){stream.getTracks().forEach(function(x){x.stop()});stream=null}camOn=0;render()}
function reattach(){var v=document.getElementById('cam');if(v&&stream){v.srcObject=stream;var p=v.play();if(p&&p.catch)p.catch(function(){})}}
function scan(){var v=document.getElementById('cam');if(!v||!v.videoWidth)return;var c=document.createElement('canvas');c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d').drawImage(v,0,0);var u=c.toDataURL('image/jpeg',.85),im=new Image();im.onload=function(){photo={src:u,size:u.length,img:im};res=null;S.fu=0;analyze()};im.src=u}

/* analyze */
function analyze(){var c=document.createElement('canvas');c.width=c.height=40;var x=c.getContext('2d');x.drawImage(photo.img,0,0,40,40);var d=x.getImageData(0,0,40,40).data,s=0;for(var i=0;i<d.length;i+=4)s+=(d[i]+d[i+1]+d[i+2])/3;s/=1600;if(s<45||s>235){res={bad:1};render();return}if(S.key){res={loading:1};render();gem()}else run()}

/* Gemini AI */
function gem(){var im=photo.img,k=Math.min(1,800/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=im.width*k;c.height=im.height*k;c.getContext('2d').drawImage(im,0,0,c.width,c.height);var b64=c.toDataURL('image/jpeg',.8).split(',')[1];
 var pr='You are a plant pathologist helping Tamil Nadu farmers. Look at the photo of a crop leaf. Return JSON only: {"is_plant":bool,"crop":"paddy|tomato|groundnut|banana|chilli|other","problem":"disease or pest name in English, or Healthy","problem_ta":"same in Tamil","confidence":0-100,"severity":"low|medium|high","symptoms_en":"one short sentence","symptoms_ta":"same in Tamil","organic_en":"organic cure with dose per litre","organic_ta":"same in Tamil","chemical_en":"chemical option with dose, or Ask agri officer","chemical_ta":"same in Tamil","prevention_en":"one short tip","prevention_ta":"same in Tamil"}. If unsure use low confidence. Never invent. Simple words.';
 fetch('https://generativelanguage.googleapis.com/v1beta/models/'+S.model+':generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':S.key},body:JSON.stringify({contents:[{parts:[{text:pr},{inline_data:{mime_type:'image/jpeg',data:b64}}]}],generationConfig:{responseMimeType:'application/json',temperature:.1}})})
 .then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.json()}).then(function(j){var o=JSON.parse(j.candidates[0].content.parts[0].text),c=Math.max(0,Math.min(100,+o.confidence||0));if(CR[o.crop])S.crop=o.crop;res={ai:o,c:c,healthy:/healthy/i.test(o.problem||'')};render();if(o.is_plant&&c>=70)speak(SP.ta,'ta')})
 .catch(function(e){res={err:String(e.message||e)};render()})}

function saveKey(){S.key=(document.getElementById('gk')||{}).value||'';S.key=S.key.trim();try{localStorage.setItem('gk',S.key)}catch(e){}render()}
function keyCard(){return '<div class="k sv" style="margin-top:18px"><h3>🔑 '+t(['Real AI scan (free Gemini key)','நிஜ AI ஸ்கேன்'])+'</h3><p style="font-size:14px">'+t(['Get a free key at aistudio.google.com/apikey and paste below.','aistudio.google.com/apikey இல் இலவச key எடுக்கவும்.'])+'</p><div class="f"><input type="password" id="gk" placeholder="AIza..." value="'+esc(S.key)+'"><button class="btn" style="margin:0" onclick="saveKey()">'+t(['Save','சேமி'])+'</button></div>'+(S.key?'<span class="tag" style="margin-top:8px">✅ '+t(['AI scan ON','AI ஸ்கேன் ON'])+'</span>':'')+'</div>'}
function fallbackCard(){return '<div class="k sr"><h3>⚠ '+t(['Not sure enough','உறுதியாக இல்லை'])+'</h3><p>'+t(['Do not spray yet. Call 1800-180-1551 (toll free).','தெளிக்க வேண்டாம். 1800-180-1551 அழைக்கவும்.'])+'</p><a class="btn" href="tel:18001801551" style="text-decoration:none;display:inline-block">📞 1800-180-1551</a></div>'}
function loadCard(){return '<div class="k"><h3>🔍 '+t(['Scanning...','ஸ்கேன்...'])+'</h3></div>'}
function errCard(){return '<div class="k sr"><h3>⚠ '+t(['Scan failed','தோல்வி'])+'</h3><p>'+esc(res.err)+'</p><button class="btn l" onclick="run()">'+t(['Use sample scan','மாதிரி ஸ்கேன்'])+'</button></div>'}
function resultAI(){var o=res.ai,c=res.c,low=!o.is_plant||c<70,cr=CR[o.crop];
 var head='<div class="k"><h3>'+(cr?cr[2]+' '+t(cr):t(['Crop not clear','பயிர் தெளிவில்லை']))+'</h3><div class="row"><span>'+t(['Problem','பிரச்சனை'])+'</span><b>'+esc(t([o.problem,o.problem_ta||o.problem]))+'</b></div><div class="bar"><i style="width:'+c+'%"></i></div><span class="tag" style="background:var(--'+(low?'rl':'gl')+')">'+t(['Confidence','நம்பகத்தன்மை'])+' '+c+'%</span> <span class="tag">'+esc(o.severity||'')+'</span><p>'+esc(t([o.symptoms_en,o.symptoms_ta]))+'</p></div>';
 if(low)return head+fallbackCard();
 SP.ta=(o.problem_ta||o.problem)+'. '+(res.healthy?'':'இயற்கை: '+o.organic_ta+'. மருந்து: '+o.chemical_ta+'. '+inL(1,spray)+' ')+(o.prevention_ta||'');
 SP.en=o.problem+'. '+(res.healthy?'':'Organic: '+o.organic_en+'. Chemical: '+o.chemical_en+'. '+inL(0,spray)+' ')+(o.prevention_en||'');
 var body=res.healthy?'<div class="k"><h3>✅ '+t(['Looks healthy','ஆரோக்கியமாக உள்ளது'])+'</h3><p>'+esc(t([o.prevention_en,o.prevention_ta]))+'</p>':'<div class="k"><h3>'+t(['How to cure','குணப்படுத்தும் முறை'])+'</h3><div class="row"><span>🌿 '+t(['Organic','இயற்கை'])+'</span><b>'+esc(t([o.organic_en,o.organic_ta]))+'</b></div><div class="row"><span>🧪 '+t(['Chemical','மருந்து'])+'</span><b>'+esc(t([o.chemical_en,o.chemical_ta]))+'</b></div><div class="row"><span>🌦 '+t(['Spray timing','தெளிக்கும் நேரம்'])+'</span><span>'+spray()+'</span></div><div class="row"><span>🛡 '+t(['Prevention','தடுப்பு'])+'</span><span>'+esc(t([o.prevention_en,o.prevention_ta]))+'</span></div><div style="font-size:13px;color:var(--mu)">'+t(['Safety: gloves and mask, keep away from water.','பாதுகாப்பு: கையுறை, முகமூடி; நீர்நிலை அருகில் தெளிக்க வேண்டாம்.'])+'</div>';
 body+='<button class="btn" onclick="speak(SP.ta,\'ta\')">🔊 தமிழ்</button> <button class="btn l" onclick="speak(SP.en,\'en\')">🔊 English</button>'+(noTa()?'<p class="tag" style="background:var(--yl);margin-top:10px">'+t(['No Tamil voice on device. Install Google Tamil TTS.','சாதனத்தில் தமிழ் குரல் இல்லை. Google Tamil TTS நிறுவவும்.'])+'</p>':'')+'</div>';
 return head+body}

/* Live weather */
function loadWx(lat,lon,name){WXL.busy=1;WXL.fail=0;render();
 fetch('https://api.open-meteo.com/v1/forecast?latitude='+lat+'&longitude='+lon+'&timezone=auto&forecast_days=3&current=temperature_2m,relative_humidity_2m,wind_speed_10m&daily=temperature_2m_max,precipitation_probability_max,precipitation_sum,et0_fao_evapotranspiration&hourly=relative_humidity_2m')
 .then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){var d=j.daily,h=j.hourly.relative_humidity_2m,L3=[['Today','இன்று'],['Tomorrow','நாளை'],['Day 3','மூன்றாம் நாள்']];
  WX=d.time.map(function(_,i){var hs=h.slice(i*24,i*24+24);return {d:L3[i],t:Math.round(d.temperature_2m_max[i]),h:Math.round(hs.reduce(function(a,b){return a+b},0)/hs.length),r:d.precipitation_probability_max[i]||0,mm:d.precipitation_sum[i]||0,et:d.et0_fao_evapotranspiration[i]}});
  WXL={live:1,name:name,now:j.current,busy:0,fail:0};render()}).catch(function(){WXL.busy=0;WXL.fail=1;WXL.live=0;render()})}
function pickCity(k){S.city=k;loadWx(LOC[k][0],LOC[k][1],k)}
function myLoc(){if(!navigator.geolocation){WXL.fail=1;render();return}navigator.geolocation.getCurrentPosition(function(p){loadWx(p.coords.latitude,p.coords.longitude,t(['My location','என் இடம்']))},function(){WXL.fail=1;render()},{timeout:8000})}
function wxBar(){var o=Object.keys(LOC).map(function(k){return '<option'+(S.city===k?' selected':'')+'>'+k+'</option>'}).join('');
 return '<div class="k sy" style="margin-bottom:18px"><div class="hs"><div><span class="tag" style="background:var(--'+(WXL.live?'gl':'yl')+')">'+(WXL.busy?'⏳ ':WXL.live?'🟢 LIVE ':'🟡 ')+(WXL.live?esc(WXL.name):t(['Sample data','மாதிரி தகவல்']))+'</span>'+(WXL.now?'<div class="big">'+Math.round(WXL.now.temperature_2m)+'°C</div><div>💧 '+WXL.now.relative_humidity_2m+'%  💨 '+Math.round(WXL.now.wind_speed_10m)+' km/h</div>':'')+(WXL.fail?'<div style="color:var(--r);font-size:14px">'+t(['Could not load live weather.','நேரடி வானிலை கிடைக்கவில்லை.'])+'</div>':'')+'</div><div style="flex:1;min-width:200px"><label>'+t(['Place','இடம்'])+'</label><select onchange="pickCity(this.value)">'+o+'</select><button class="btn" onclick="myLoc()">📍 '+t(['Use my location','என் இடம்'])+'</button></div></div></div>'}

/* Init */
try{speechSynthesis.onvoiceschanged=function(){}}catch(e){}
document.getElementById('lb').onclick=function(){L=L?0:1;render()};

/* Register service worker for PWA offline */
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('/sw.js').catch(function(){});
}

render();
loadWx(LOC.Madurai[0],LOC.Madurai[1],'Madurai');
checkBackend();
loadOutbreaks();
loadStressAlerts();

/* ================================================================
   FEATURE 1 UI: CROP STRESS EARLY WARNING
================================================================ */
var STRESS_ALERTS = null;

function loadStressAlerts(){
  fetch(API+'/api/stress/alerts')
    .then(function(r){return r.json()})
    .then(function(j){ STRESS_ALERTS=j.alerts||[]; render(); })
    .catch(function(){ STRESS_ALERTS=[]; });
}

function runStressCheck(){
  var el=document.getElementById('stressCheckMsg');
  if(el) el.innerHTML='<p>'+t(['Checking weather conditions...','வானிலை சரிபார்க்கிறது...'])+'</p>';
  fetch(API+'/api/stress/predict?crop='+S.crop+'&lat='+(WXL.now?9.92:9.92)+'&lon=78.12')
    .then(function(r){return r.json()})
    .then(function(j){
      STRESS_PRED=j.predictions||[];
      render();
      var el2=document.getElementById('stressCheckMsg');
      if(el2) el2.innerHTML='<span class="tag" style="background:var(--gl)">✅ '+t(['Prediction updated','கணிப்பு புதுப்பிக்கப்பட்டது'])+'</span>';
    })
    .catch(function(){
      var el2=document.getElementById('stressCheckMsg');
      if(el2) el2.innerHTML='<span class="tag" style="background:var(--rl)">'+t(['Backend offline','சர்வர் இல்லை'])+'</span>';
    });
}

var STRESS_PRED = null;

function stressSection(){
  var riskColor={'critical':'rl','high':'rl','medium':'yl','low':'gl','none':'gl'};
  var riskEmoji={'critical':'🔴','high':'🟠','medium':'🟡','low':'🟢','none':'✅'};

  // Live prediction for current crop
  var predHtml='';
  if(STRESS_PRED && STRESS_PRED.length){
    predHtml=STRESS_PRED.map(function(p){
      var col=riskColor[p.riskLevel]||'yl';
      var em=riskEmoji[p.riskLevel]||'🟡';
      return '<div class="k s'+(p.riskLevel==='low'||p.riskType==='none'?'g':'r')+'" style="margin-bottom:12px">'+
        '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">'+
        '<span style="font-size:28px">'+em+'</span>'+
        '<div><h3 style="margin:0">'+esc(t([p.disease,p.disease_ta||p.disease]))+'</h3>'+
        '<span class="tag" style="background:var(--'+col+')">'+esc(p.riskLevel.toUpperCase())+' RISK | '+p.daysAhead+' '+t(['days ahead','நாட்களில்'])+'</span></div></div>'+
        '<p>'+esc(t([p.message_en,p.message_ta]))+'</p>'+
        '<div style="background:var(--gl);border-radius:10px;padding:8px 12px;font-size:13px">'+
        '💊 <b>'+t(['Preventive action','தடுப்பு நடவடிக்கை'])+':</b> '+esc(t([p.preventiveAction_en,p.preventiveAction_ta]))+
        '</div></div>';
    }).join('');
  } else {
    predHtml='<div class="k"><p>'+t(['Click "Check now" to get a real-time stress prediction for your crop.','கீழே "இப்போது சரிபார்" அழுத்தி நேரடி கணிப்பு பெறுங்கள்.'])+'</p></div>';
  }

  // Active DB alerts
  var alertRows='';
  if(STRESS_ALERTS && STRESS_ALERTS.length){
    alertRows=STRESS_ALERTS.slice(0,5).map(function(a){
      var col=riskColor[a.riskLevel]||'yl';
      return '<div class="row"><span>'+esc(a.village)+' – '+esc(a.crop)+'<br><small>'+esc(t([a.message_en,a.message_ta]).substring(0,70))+'...</small></span>'+
        '<span class="tag" style="background:var(--'+col+')">'+esc(a.riskLevel)+'</span></div>';
    }).join('');
  } else {
    alertRows='<p style="font-size:13px;color:var(--mu)">'+t(['No active alerts. Click Check now.','செயலில் எச்சரிக்கைகள் இல்லை.'])+'</p>';
  }

  var b='<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">'+
    '<div>'+
    '<div class="k sy" style="margin-bottom:14px">'+
    '<h3>'+t(['Real-time prediction for your','உங்கள் பயிருக்கான நேரடி கணிப்பு'])+' '+CR[S.crop][2]+' '+t(CR[S.crop])+'</h3>'+
    '<button class="btn" onclick="runStressCheck()">🔍 '+t(['Check now','இப்போது சரிபார்'])+'</button>'+
    ' <div id="stressCheckMsg" style="display:inline-block;margin-left:8px"></div>'+
    '</div>'+
    predHtml+'</div>'+
    '<div class="k">'+
    '<h3>'+t(['Active alerts from DB','DB இல் உள்ள எச்சரிக்கைகள்'])+'</h3>'+
    '<p style="font-size:13px;color:var(--mu)">'+t(['Generated every 6 hours from live weather. Farmers get SMS 2-3 days before symptoms.','ஒவ்வொரு 6 மணிக்கும் நேரடி வானிலை மூலம். அறிகுறிகளுக்கு 2-3 நாள் முன்பே SMS.'])+'</p>'+
    alertRows+
    '</div></div>';

  return sec('sr','🧬','stress',['Crop Stress Early Warning','ஆரம்ப நோய் எச்சரிக்கை'],b);
}

/* ================================================================
   FEATURE 2 UI: CHEMICAL RESISTANCE TRACKER
================================================================ */
var SPRAY_HISTORY = null;

function loadSprayHistory(){
  var phone=getFarmerPhone();
  if(!phone) return;
  fetch(API+'/api/spray/history/'+phone)
    .then(function(r){return r.json()})
    .then(function(j){ SPRAY_HISTORY=j; render(); })
    .catch(function(){});
}

function logSpray(){
  var phone=getFarmerPhone();
  var chemical=(document.getElementById('sprayChemical')||{}).value||'';
  var dose=(document.getElementById('sprayDose')||{}).value||'';
  var el=document.getElementById('sprayLogMsg');
  if(!phone){if(el)el.innerHTML='<p class="tag" style="background:var(--yl)">'+t(['Register phone first.','முதலில் போன் பதிவு செய்யுங்கள்.'])+'</p>';return;}
  if(!chemical){if(el)el.innerHTML='<p style="color:var(--r)">'+t(['Select a chemical.','மருந்து தேர்வு செய்யுங்கள்.'])+'</p>';return;}

  var disease='';
  var disease_ta='';
  if(res&&res.list){disease=res.list[0].d[0];disease_ta=res.list[0].d[1];}
  else if(res&&res.ai){disease=res.ai.problem||'';disease_ta=res.ai.problem_ta||'';}

  if(el)el.innerHTML='<p>'+t(['Logging...','சேமிக்கிறது...'])+'</p>';

  fetch(API+'/api/spray/log',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({phone,crop:S.crop,disease:disease||S.crop+' disease',chemical,dose,sprayDate:new Date()})
  })
  .then(function(r){return r.json()})
  .then(function(j){
    var warn=j.warning;
    if(warn){
      if(el)el.innerHTML='<div class="k sr" style="margin-top:10px"><h3>⚠️ '+t(['Resistance Warning!','எதிர்ப்பு எச்சரிக்கை!'])+'</h3>'+
        '<p>'+esc(t([warn.message_en,warn.message_ta]))+'</p>'+
        '<p><b>'+t(['Try instead:','மாற்று:'])+'</b> '+esc((warn.alternatives||[]).join(', '))+'</p></div>';
    } else {
      if(el)el.innerHTML='<span class="tag" style="background:var(--gl);margin-top:8px">✅ '+t(['Spray logged. Total uses:','தெளிப்பு சேமிக்கப்பட்டது. மொத்தம்:'])+' '+j.count+'</span>';
    }
    loadSprayHistory();
  })
  .catch(function(){
    if(el)el.innerHTML='<span class="tag" style="background:var(--yl)">'+t(['Backend offline.','சர்வர் இல்லை.'])+'</span>';
  });
}

function resistanceSection(){
  var chemicals=['Mancozeb','Tricyclazole','Chlorothalonil','Tebuconazole','Propiconazole','Carbendazim','Neem oil (organic)'];
  var riskColor={critical:'rl',high:'rl',medium:'yl',low:'gl'};
  var riskEmoji={critical:'🔴',high:'🟠',medium:'🟡',low:'🟢'};

  var logForm='<div class="k" style="margin-bottom:14px">'+
    '<h3>'+t(['Log today\'s spray','இன்றைய தெளிப்பை பதிவு செய்'])+'</h3>'+
    '<p style="font-size:13px;color:var(--mu)">'+t(['Every spray is saved. After 3 uses of same chemical, a resistance warning is triggered.','ஒவ்வொரு தெளிப்பும் சேமிக்கப்படும். ஒரே மருந்தை 3 முறை தெளித்தால் எதிர்ப்பு எச்சரிக்கை வரும்.'])+'</p>'+
    '<div class="f">'+
    '<div><label>'+t(['Chemical used','பயன்படுத்திய மருந்து'])+'</label>'+
    '<select id="sprayChemical"><option value="">'+t(['-- Select --','-- தேர்வு --'])+'</option>'+
    chemicals.map(function(c){return '<option value="'+c+'">'+c+'</option>';}).join('')+
    '</select></div>'+
    '<div><label>'+t(['Dose (e.g. 2g/L)','அளவு (எ.கா. 2 கி/லி)'])+'</label>'+
    '<input id="sprayDose" type="text" placeholder="2g/L"></div>'+
    '<div style="display:flex;align-items:flex-end"><button class="btn" onclick="logSpray()">📝 '+t(['Log spray','பதிவு செய்'])+'</button></div>'+
    '</div><div id="sprayLogMsg"></div>'+
    '<p style="font-size:12px;color:var(--mu);margin-top:6px">'+t(['Spray logged for crop: ','பயிர்: '])+CR[S.crop][2]+' '+t(CR[S.crop])+(res&&(res.list||res.ai)?' | '+t(['Disease: ','நோய்: '])+(res.list?esc(res.list[0].d[0]):res.ai?esc(res.ai.problem):''):'')+'</p>'+
    '</div>';

  var histHtml='';
  if(SPRAY_HISTORY && SPRAY_HISTORY.resistanceReport && SPRAY_HISTORY.resistanceReport.length){
    histHtml='<div class="k" style="margin-bottom:14px"><h3>'+t(['Resistance report (last 90 days)','எதிர்ப்பு அறிக்கை (கடந்த 90 நாட்கள்)'])+'</h3>'+
      SPRAY_HISTORY.resistanceReport.map(function(r){
        var col=riskColor[r.risk]||'yl';
        var em=riskEmoji[r.risk]||'🟡';
        return '<div class="row"><span>'+esc(r.disease)+' → '+esc(r.chemical)+'<br><small>'+r.count+' '+t(['uses','முறை'])+' | '+t(['alternatives:','மாற்று:'])+' '+esc((r.alternatives||[]).join(', '))+'</small></span>'+
          '<span class="tag" style="background:var(--'+col+')">'+em+' '+esc(r.risk.toUpperCase())+'</span></div>';
      }).join('')+'</div>';

    histHtml+='<div class="k"><h3>'+t(['Recent sprays','சமீபத்திய தெளிப்புகள்'])+'</h3>'+
      (SPRAY_HISTORY.sprays||[]).slice(0,6).map(function(s){
        var d=new Date(s.sprayDate).toLocaleDateString('en-IN');
        return '<div class="row"><span>'+esc(s.chemical)+' – '+esc(s.disease)+'<br><small>'+d+' | '+esc(s.dose)+'</small></span>'+
          '<span class="tag">'+esc(s.crop)+'</span></div>';
      }).join('')+'</div>';
  } else {
    histHtml='<div class="k"><p style="color:var(--mu);font-size:14px">'+
      t(['No spray history yet. Register your phone and log your first spray above.','தெளிப்பு வரலாறு இல்லை. போன் பதிவு செய்து மேலே முதல் தெளிப்பை சேமிக்கவும்.'])+'</p>'+
      '<button class="btn l" onclick="loadSprayHistory()">🔄 '+t(['Refresh','புதுப்பி'])+'</button></div>';
  }

  var b='<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">'+
    '<div>'+logForm+'</div>'+
    '<div>'+histHtml+'</div></div>';

  return sec('sv','🧪','resistance',['Chemical Resistance Tracker','மருந்து எதிர்ப்பு கண்காணிப்பு'],b);
}

/* ================================================================
   FEATURE 3 UI: LEAF PROGRESS TRACKER (Before vs After)
================================================================ */
var LEAF_PROGRESS = null;

function loadLeafProgress(){
  var phone=getFarmerPhone();
  if(!phone) return;
  fetch(API+'/api/progress/'+phone)
    .then(function(r){return r.json()})
    .then(function(j){ LEAF_PROGRESS=j.records||[]; render(); })
    .catch(function(){});
}

function saveProgressScan(){
  var phone=getFarmerPhone();
  var el=document.getElementById('progressMsg');
  if(!phone){
    if(el)el.innerHTML='<p class="tag" style="background:var(--yl)">'+t(['Register phone first.','முதலில் போன் பதிவு செய்யுங்கள்.'])+'</p>';
    return;
  }
  if(!res||(!(res.list)&&!(res.ai))){
    if(el)el.innerHTML='<p class="tag" style="background:var(--yl)">'+t(['Diagnose a leaf first, then save to timeline.','முதலில் இலை நோயை கண்டறியுங்கள்.'])+'</p>';
    return;
  }

  var disease='', disease_ta='', confidence=0, severity='unknown', problem='';
  if(res.ai){
    disease=res.ai.problem||''; disease_ta=res.ai.problem_ta||'';
    confidence=res.c||0; severity=res.ai.severity||'unknown'; problem=res.ai.problem||'';
  } else if(res.list){
    disease=res.list[0].d[0]; disease_ta=res.list[0].d[1];
    confidence=res.c||0; severity='medium'; problem=disease;
  }

  var note=(document.getElementById('progressNote')||{}).value||('Day '+new Date().toLocaleDateString('en-IN'));
  if(el)el.innerHTML='<p>'+t(['Saving scan to timeline...','காலவரிசையில் சேமிக்கிறது...'])+'</p>';

  fetch(API+'/api/progress/scan',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({phone,crop:S.crop,disease,confidence,severity,problem,note})
  })
  .then(function(r){return r.json()})
  .then(function(j){
    var trend=j.trend||{};
    var statusColor={healed:'gl',improving:'gl',worsening:'rl',stable:'yl',pending:'yl'};
    var col=statusColor[trend.status]||'yl';
    if(el)el.innerHTML='<div class="k" style="margin-top:10px;padding:12px;background:var(--'+col+')">'+
      '<b>'+esc(t([trend.message_en,trend.message_ta]))+'</b>'+
      (trend.scans>1?'<br><small>'+trend.scans+' '+t(['scans recorded','ஸ்கேன்கள்'])+'</small>':'')+
      '</div>';
    loadLeafProgress();
  })
  .catch(function(){
    if(el)el.innerHTML='<span class="tag" style="background:var(--yl)">'+t(['Backend offline.','சர்வர் இல்லை.'])+'</span>';
  });
}

function progressSection(){
  var saveCard='<div class="k" style="margin-bottom:14px">'+
    '<h3>'+t(['Save this scan to timeline','இந்த ஸ்கேனை காலவரிசையில் சேமி'])+'</h3>'+
    '<p style="font-size:13px;color:var(--mu)">'+t(['Diagnose a leaf above, then save it here. Scan again in 5 days to compare.','மேலே இலை நோயை கண்டறிந்து, இங்கே சேமிக்கவும். 5 நாள் பின் மீண்டும் ஸ்கேன் செய்யுங்கள்.'])+'</p>'+
    '<div class="f">'+
    '<div><label>'+t(['Note (optional)','குறிப்பு (விரும்பினால்)'])+'</label>'+
    '<input id="progressNote" type="text" placeholder="'+t(['e.g. Day 1 before spray','எ.கா. தெளிப்புக்கு முன்'])+'"></div>'+
    '<div style="display:flex;align-items:flex-end"><button class="btn" onclick="saveProgressScan()">📸 '+t(['Save scan','ஸ்கேன் சேமி'])+'</button></div>'+
    '</div>'+
    (res&&(res.list||res.ai)?
      '<p style="font-size:12px;color:var(--mu);margin-top:6px">'+t(['Current scan: ','இப்போதைய ஸ்கேன்: '])+
      esc(res.ai?res.ai.problem:res.list?res.list[0].d[0]:'')+ ' | '+
      t(['Confidence: ','நம்பகம்: '])+(res.c||0)+'%</p>':'<p style="font-size:12px;color:var(--mu)">'+t(['No active scan — diagnose a leaf first.','செயலில் ஸ்கேன் இல்லை — முதலில் இலையை கண்டறியுங்கள்.'])+'</p>')+
    '<div id="progressMsg"></div></div>';

  var timelineHtml='';
  if(LEAF_PROGRESS && LEAF_PROGRESS.length){
    timelineHtml=LEAF_PROGRESS.map(function(rec){
      var trend=rec.trend||{};
      var statusColor={healed:'gl',improving:'gl',worsening:'rl',stable:'yl',pending:'yl'};
      var statusEmoji={healed:'✅',improving:'📈',worsening:'📉',stable:'➡️',pending:'🕐'};
      var col=statusColor[trend.status]||'yl';
      var em=statusEmoji[trend.status]||'🕐';

      var scanRows=(rec.scans||[]).map(function(s,i){
        var d=new Date(s.date).toLocaleDateString('en-IN');
        var sevColor={healthy:'gl',low:'gl',medium:'yl',high:'rl',unknown:'yl'};
        var sc=sevColor[s.severity]||'yl';
        return '<div style="display:flex;gap:8px;align-items:center;padding:6px 0;border-bottom:1px dashed var(--al)">'+
          '<span style="min-width:24px;font-weight:800;color:var(--mu)">'+(i+1)+'</span>'+
          '<span class="tag" style="background:var(--'+sc+');font-size:12px">'+esc(s.severity)+'</span>'+
          '<span style="font-size:13px">'+esc(s.problem||'Healthy')+'</span>'+
          '<span style="font-size:12px;color:var(--mu);margin-left:auto">'+d+'</span>'+
          '</div>';
      }).join('');

      return '<div class="k" style="margin-bottom:14px">'+
        '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">'+
        '<span style="font-size:24px">'+em+'</span>'+
        '<div><h3 style="margin:0">'+CR[rec.crop][2]+' '+esc(rec.disease||t(['Monitoring','கண்காணிப்பு']))+'</h3>'+
        '<span class="tag" style="background:var(--'+col+')">'+esc(t([trend.message_en,trend.message_ta]))+'</span></div></div>'+
        '<div style="font-size:13px">'+scanRows+'</div>'+
        (rec.scans.length>=2?
          '<div style="margin-top:8px;padding:8px;background:var(--al);border-radius:8px;font-size:13px">'+
          '📊 '+rec.scans.length+' '+t(['scans | First severity:','ஸ்கேன்கள் | முதல் நிலை:'])+' '+esc(trend.firstSeverity)+' → '+t(['Now:','இப்போது:'])+' '+esc(trend.lastSeverity)+
          '</div>':'<p style="font-size:12px;color:var(--mu)">'+t(['Scan again in 5 days to see trend.','5 நாள் பின் மீண்டும் ஸ்கேன் செய்யுங்கள்.'])+'</p>')+
        '</div>';
    }).join('');
  } else {
    timelineHtml='<div class="k"><p style="color:var(--mu);font-size:14px">'+
      t(['No timeline yet. Save your first scan above after diagnosing a leaf.','காலவரிசை இல்லை. இலை நோயை கண்டறிந்து மேலே முதல் ஸ்கேனை சேமிக்கவும்.'])+'</p>'+
      '<button class="btn l" onclick="loadLeafProgress()">🔄 '+t(['Refresh','புதுப்பி'])+'</button></div>';
  }

  var b='<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">'+
    '<div>'+saveCard+'</div>'+
    '<div>'+
    '<div class="k sy" style="margin-bottom:14px"><h3>'+t(['How it works','எவ்வாறு செயல்படுகிறது'])+'</h3>'+
    '<div class="steps"><div class="k sg">'+t(['Scan & diagnose your leaf today','இன்று இலையை ஸ்கேன் செய்யுங்கள்'])+'</div>'+
    '<div class="k sy">'+t(['Save it to the timeline','காலவரிசையில் சேமிக்கவும்'])+'</div>'+
    '<div class="k sb">'+t(['Spray as advised','ஆலோசனைப்படி தெளிக்கவும்'])+'</div>'+
    '<div class="k sv">'+t(['Scan again in 5 days','5 நாள் பின் மீண்டும் ஸ்கேன்'])+'</div>'+
    '<div class="k sp">'+t(['AI shows: improving / worsening / healed','AI காட்டும்: முன்னேற்றம் / மோசம் / குணம்'])+'</div>'+
    '</div></div>'+
    timelineHtml+
    '</div></div>';

  return sec('sp','📸','progress',['Leaf Progress Tracker','இலை முன்னேற்ற கண்காணிப்பு'],b);
}
