'use strict';
require('dotenv').config();

const express = require('express');
const cors    = require('cors');
const mongoose = require('mongoose');
const cron    = require('node-cron');
const axios   = require('axios');

const app  = express();
const PORT = process.env.PORT || 3001;

/* ─── Middleware ─────────────────────────────────────────── */
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || 'http://localhost:3001',
    'http://127.0.0.1:3001',
    'http://localhost:8000',
    'http://127.0.0.1:8000',
    'http://localhost:5500',
    'http://127.0.0.1:5500'
  ],
  methods: ['GET','POST','PUT','DELETE'],
  credentials: true
}));
app.use(express.json({ limit: '5mb' }));

/* ─── MongoDB Connection ─────────────────────────────────── */
let dbConnected = false;

mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/pasumai')
  .then(() => { dbConnected = true; console.log('✅ MongoDB connected'); })
  .catch(err => {
    console.warn('⚠️  MongoDB not available – running in MEMORY mode:', err.message);
    console.warn('   Install MongoDB or use MongoDB Atlas free tier.');
  });

/* ─── Schemas & Models ───────────────────────────────────── */

// 1. Farmer registration (phone, village, crop) – used for SMS + reminders
const farmerSchema = new mongoose.Schema({
  phone:    { type: String, required: true, unique: true },
  name:     { type: String, default: 'Farmer' },
  village:  { type: String, default: '' },
  crop:     { type: String, default: 'tomato' },
  lang:     { type: String, default: 'ta' },   // ta | en
  lat:      { type: Number, default: 9.92 },
  lon:      { type: Number, default: 78.12 },
  createdAt:{ type: Date,   default: Date.now }
});
const Farmer = mongoose.models.Farmer || mongoose.model('Farmer', farmerSchema);

// 2. Disease reports – real outbreak data
const outbreakSchema = new mongoose.Schema({
  village:  { type: String, required: true },
  crop:     { type: String, required: true },
  disease:  { type: String, required: true },
  disease_ta:{ type: String, default: '' },
  cases:    { type: Number, default: 1 },
  lat:      { type: Number, default: 9.92 },
  lon:      { type: Number, default: 78.12 },
  reportedBy:{ type: String, default: 'anonymous' },
  createdAt: { type: Date, default: Date.now }
});
const Outbreak = mongoose.models.Outbreak || mongoose.model('Outbreak', outbreakSchema);

// 3. Follow-up reminders – saved to DB, not memory
const reminderSchema = new mongoose.Schema({
  phone:      { type: String, required: true },
  disease:    { type: String, default: '' },
  disease_ta: { type: String, default: '' },
  crop:       { type: String, default: '' },
  sprayDate:  { type: Date, default: Date.now },
  followUpDate:{ type: Date, required: true },
  sent:       { type: Boolean, default: false },
  createdAt:  { type: Date, default: Date.now }
});
const Reminder = mongoose.models.Reminder || mongoose.model('Reminder', reminderSchema);

// 4. IVR call logs
const ivrSchema = new mongoose.Schema({
  phone:    { type: String, default: 'unknown' },
  crop:     { type: String, default: '' },
  symptoms: { type: String, default: '' },
  result:   { type: String, default: '' },
  callType: { type: String, default: 'ivr' },  // ivr | missedcall
  createdAt:{ type: Date, default: Date.now }
});
const IVRLog = mongoose.models.IVRLog || mongoose.model('IVRLog', ivrSchema);

// 5. SMS logs
const smsLogSchema = new mongoose.Schema({
  phone:    { type: String, required: true },
  message:  { type: String, required: true },
  type:     { type: String, default: 'manual' }, // manual | reminder | outbreak | weather
  status:   { type: String, default: 'pending' }, // pending | sent | failed | simulated
  createdAt:{ type: Date, default: Date.now }
});
const SMSLog = mongoose.models.SMSLog || mongoose.model('SMSLog', smsLogSchema);

// 6. Chemical spray log – resistance tracker
const sprayLogSchema = new mongoose.Schema({
  phone:      { type: String, required: true },
  crop:       { type: String, required: true },
  disease:    { type: String, required: true },
  chemical:   { type: String, required: true },  // e.g. "Mancozeb"
  chemical_ta:{ type: String, default: '' },
  dose:       { type: String, default: '' },
  sprayDate:  { type: Date,   default: Date.now },
  effective:  { type: String, default: 'unknown' }, // 'yes'|'no'|'unknown'
  createdAt:  { type: Date,   default: Date.now }
});
const SprayLog = mongoose.models.SprayLog || mongoose.model('SprayLog', sprayLogSchema);

// 7. Leaf progress tracker – before/after photos
const leafProgressSchema = new mongoose.Schema({
  phone:       { type: String, required: true },
  crop:        { type: String, required: true },
  disease:     { type: String, default: '' },
  scans:       [{
    date:      { type: Date, default: Date.now },
    confidence:{ type: Number, default: 0 },
    severity:  { type: String, default: '' },   // low|medium|high|healthy
    problem:   { type: String, default: '' },
    note:      { type: String, default: '' }
  }],
  createdAt:   { type: Date, default: Date.now }
});
const LeafProgress = mongoose.models.LeafProgress || mongoose.model('LeafProgress', leafProgressSchema);

// 8. Crop stress early warnings
const stressAlertSchema = new mongoose.Schema({
  village:    { type: String, default: 'General' },
  crop:       { type: String, required: true },
  riskType:   { type: String, required: true },  // blast|blight|thrips|rust
  riskLevel:  { type: String, default: 'medium' }, // low|medium|high|critical
  message_en: { type: String, default: '' },
  message_ta: { type: String, default: '' },
  weatherData:{ type: Object, default: {} },
  daysAhead:  { type: Number, default: 3 },      // predicted days before symptoms
  notified:   { type: Boolean, default: false },
  createdAt:  { type: Date, default: Date.now }
});
const StressAlert = mongoose.models.StressAlert || mongoose.model('StressAlert', stressAlertSchema);

/* ─── In-memory fallback store (when MongoDB is offline) ─── */
const mem = { farmers:[], outbreaks:[], reminders:[], ivr:[], sms:[], sprays:[], progress:[], stress:[] };

/* ─── SMS Helper ─────────────────────────────────────────── */
async function sendSMS(phone, message, type = 'manual') {
  const logEntry = { phone, message, type, status: 'pending', createdAt: new Date() };

  // Try MSG91 if API key is set
  if (process.env.MSG91_API_KEY) {
    try {
      const clean = phone.replace(/\D/g,'');
      const mobile = clean.startsWith('91') ? clean : '91' + clean;
      await axios.post('https://api.msg91.com/api/v2/sendsms', {
        sender: process.env.MSG91_SENDER_ID || 'PSMKVL',
        route: process.env.MSG91_ROUTE || '4',
        country: '91',
        sms: [{ message, to: [mobile] }]
      }, {
        headers: {
          'authkey': process.env.MSG91_API_KEY,
          'Content-Type': 'application/json'
        }
      });
      logEntry.status = 'sent';
      console.log(`📱 SMS SENT to ${phone}: ${message}`);
    } catch (err) {
      logEntry.status = 'failed';
      console.error('SMS send error:', err.message);
    }
  } else {
    // Simulation mode – log to console
    logEntry.status = 'simulated';
    console.log(`📱 [SIMULATED SMS] → ${phone}: ${message}`);
  }

  // Save log to DB or memory
  try {
    if (dbConnected) await SMSLog.create(logEntry);
    else mem.sms.push(logEntry);
  } catch(e) { /* ignore log failures */ }

  return logEntry;
}

/* ─── ROUTES ─────────────────────────────────────────────── */

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    db: dbConnected ? 'mongodb' : 'memory',
    sms: process.env.MSG91_API_KEY ? 'msg91' : 'simulation',
    time: new Date().toISOString()
  });
});

/* === 1. FARMER REGISTRATION ================================ */
app.post('/api/farmer/register', async (req, res) => {
  try {
    const { phone, name, village, crop, lang, lat, lon } = req.body;
    if (!phone) return res.status(400).json({ ok: false, error: 'Phone required' });

    if (dbConnected) {
      const farmer = await Farmer.findOneAndUpdate(
        { phone },
        { name, village, crop, lang, lat, lon },
        { upsert: true, new: true }
      );
      res.json({ ok: true, farmer });
    } else {
      const idx = mem.farmers.findIndex(f => f.phone === phone);
      const f = { phone, name, village, crop, lang, lat, lon, createdAt: new Date() };
      if (idx >= 0) mem.farmers[idx] = f; else mem.farmers.push(f);
      res.json({ ok: true, farmer: f });
    }

    // Welcome SMS
    const msg = lang === 'ta'
      ? `வணக்கம் ${name||''}! பசுமை காவலனில் பதிவு செய்தீர்கள். நோய், தண்ணீர், வானிலை தகவல்கள் கிடைக்கும்.`
      : `Welcome ${name||''}! Registered on Pasumai Kavalan. You will get disease, water and weather alerts.`;
    sendSMS(phone, msg, 'welcome');

  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/api/farmer/:phone', async (req, res) => {
  try {
    const { phone } = req.params;
    if (dbConnected) {
      const farmer = await Farmer.findOne({ phone });
      return res.json({ ok: true, farmer: farmer || null });
    }
    const farmer = mem.farmers.find(f => f.phone === phone) || null;
    res.json({ ok: true, farmer });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/* === 2. OUTBREAK ALERTS ==================================== */

// Report a new disease case
app.post('/api/outbreak/report', async (req, res) => {
  try {
    const { village, crop, disease, disease_ta, lat, lon, reportedBy } = req.body;
    if (!village || !crop || !disease)
      return res.status(400).json({ ok: false, error: 'village, crop, disease required' });

    let record;
    if (dbConnected) {
      // Check if same village+crop+disease reported in last 7 days
      const cutoff = new Date(Date.now() - 7*24*60*60*1000);
      record = await Outbreak.findOne({ village, crop, disease, createdAt: { $gte: cutoff } });
      if (record) {
        record.cases += 1;
        await record.save();
      } else {
        record = await Outbreak.create({ village, crop, disease, disease_ta, lat, lon, reportedBy, cases: 1 });
      }
    } else {
      const cutoff = new Date(Date.now() - 7*24*60*60*1000);
      record = mem.outbreaks.find(o =>
        o.village === village && o.crop === crop && o.disease === disease &&
        new Date(o.createdAt) >= cutoff
      );
      if (record) { record.cases += 1; }
      else {
        record = { village, crop, disease, disease_ta, lat, lon, reportedBy, cases:1, createdAt: new Date() };
        mem.outbreaks.push(record);
      }
    }

    // If 3+ cases → send SMS alerts to nearby farmers
    if (record.cases >= 3) {
      notifyNearbyFarmers(village, crop, disease, disease_ta, lat, lon);
    }

    res.json({ ok: true, record });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Get all recent outbreak alerts (last 14 days)
app.get('/api/outbreak/list', async (req, res) => {
  try {
    const cutoff = new Date(Date.now() - 14*24*60*60*1000);
    let outbreaks;
    if (dbConnected) {
      outbreaks = await Outbreak.find({ createdAt: { $gte: cutoff } }).sort({ cases: -1 }).limit(20);
    } else {
      outbreaks = mem.outbreaks
        .filter(o => new Date(o.createdAt) >= cutoff)
        .sort((a,b) => b.cases - a.cases)
        .slice(0,20);
    }

    // Always include sample data if no real data yet
    if (outbreaks.length === 0) {
      outbreaks = getSampleOutbreaks();
    }

    res.json({ ok: true, outbreaks, source: outbreaks[0]?._id ? 'db' : 'sample' });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

function getSampleOutbreaks() {
  return [
    { village:'Melur', crop:'tomato', disease:'Early blight', disease_ta:'இலை கருகல்', cases:5, lat:9.96, lon:78.33, createdAt: new Date() },
    { village:'Thirumangalam', crop:'paddy', disease:'Rice blast', disease_ta:'குலை நோய்', cases:4, lat:9.82, lon:77.99, createdAt: new Date() },
    { village:'Usilampatti', crop:'groundnut', disease:'Tikka leaf spot', disease_ta:'டிக்கா இலைப்புள்ளி', cases:2, lat:9.97, lon:77.79, createdAt: new Date() }
  ];
}

async function notifyNearbyFarmers(village, crop, disease, disease_ta, lat, lon) {
  try {
    let farmers = [];
    if (dbConnected) farmers = await Farmer.find({ crop });
    else farmers = mem.farmers.filter(f => f.crop === crop);

    for (const f of farmers) {
      const dist = getDistKm(lat||9.92, lon||78.12, f.lat||9.92, f.lon||78.12);
      if (dist < 50) { // within 50 km
        const msg = f.lang === 'ta'
          ? `⚠️ ${village}ல் ${crop} பயிரில் ${disease_ta||disease} நோய் பரவுகிறது. தடுப்பு தெளிப்பு செய்யவும். உதவி: 1800-180-1551`
          : `⚠️ ${disease} spreading in ${village} for ${crop}. Do preventive spray. Help: 1800-180-1551`;
        await sendSMS(f.phone, msg, 'outbreak');
      }
    }
  } catch(e) { console.error('Notify error:', e.message); }
}

function getDistKm(lat1, lon1, lat2, lon2) {
  const R = 6371, dL = (lat2-lat1)*Math.PI/180, dO = (lon2-lon1)*Math.PI/180;
  const a = Math.sin(dL/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dO/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

/* === 3. FOLLOW-UP REMINDER ================================= */

// Save a follow-up reminder to DB
app.post('/api/reminder/set', async (req, res) => {
  try {
    const { phone, disease, disease_ta, crop, daysLater = 5 } = req.body;
    if (!phone) return res.status(400).json({ ok: false, error: 'Phone required' });

    const followUpDate = new Date(Date.now() + daysLater * 24 * 60 * 60 * 1000);
    const data = { phone, disease, disease_ta, crop, followUpDate, sent: false, createdAt: new Date() };

    if (dbConnected) {
      // Remove old unsent reminders for this phone
      await Reminder.deleteMany({ phone, sent: false });
      await Reminder.create(data);
    } else {
      mem.reminders = mem.reminders.filter(r => r.phone !== phone || r.sent);
      mem.reminders.push(data);
    }

    // Confirmation SMS
    const msg = `✅ Reminder set! We will ask about your ${disease||crop||'crop'} on ${followUpDate.toLocaleDateString('en-IN')}. Pasumai Kavalan`;
    await sendSMS(phone, msg, 'reminder');

    res.json({ ok: true, followUpDate });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Get reminders for a phone number
app.get('/api/reminder/:phone', async (req, res) => {
  try {
    const { phone } = req.params;
    let reminders;
    if (dbConnected) {
      reminders = await Reminder.find({ phone, sent: false }).sort({ followUpDate: 1 });
    } else {
      reminders = mem.reminders.filter(r => r.phone === phone && !r.sent);
    }
    res.json({ ok: true, reminders });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/* === 4. IVR CALL SIMULATION ================================ */

// Log IVR session result and send SMS with advice
app.post('/api/ivr/result', async (req, res) => {
  try {
    const { phone, crop, symptoms, result, callType = 'ivr' } = req.body;

    const logData = { phone: phone||'unknown', crop, symptoms, result, callType, createdAt: new Date() };

    if (dbConnected) await IVRLog.create(logData);
    else mem.ivr.push(logData);

    // Send real SMS with the IVR result
    if (phone && phone !== 'unknown') {
      const msg = `📞 Pasumai Kavalan IVR Result:\n${result}\nHelpline: 1800-180-1551`;
      await sendSMS(phone, msg.substring(0, 160), 'ivr');
    }

    res.json({ ok: true, logged: true });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/* === 5. MISSED CALL – callback SMS ========================= */

app.post('/api/missedcall', async (req, res) => {
  try {
    const { phone, crop, village } = req.body;
    if (!phone) return res.status(400).json({ ok: false, error: 'Phone required' });

    // Look up farmer data for personalised message
    let farmer = null;
    if (dbConnected) farmer = await Farmer.findOne({ phone });
    else farmer = mem.farmers.find(f => f.phone === phone) || null;

    const cropName = farmer?.crop || crop || 'crop';
    const lang     = farmer?.lang || 'ta';

    const msg = lang === 'ta'
      ? `வணக்கம்! பசுமை காவலன் – உங்கள் ${cropName} பயிருக்கு உதவி: http://localhost:3001 | நோய்க்கு: 1800-180-1551 (இலவசம்)`
      : `Hello! Pasumai Kavalan – Farm help for ${cropName}: http://localhost:3001 | Disease helpline: 1800-180-1551 (free)`;

    await sendSMS(phone, msg.substring(0, 160), 'missedcall');

    const logData = { phone, crop: cropName, callType:'missedcall', result: msg, symptoms:'', createdAt: new Date() };
    if (dbConnected) await IVRLog.create(logData);
    else mem.ivr.push(logData);

    res.json({ ok: true, message: 'Callback SMS sent', preview: msg });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/* === 6. DIRECT SMS SEND =================================== */

app.post('/api/sms/send', async (req, res) => {
  try {
    const { phone, message, type } = req.body;
    if (!phone || !message) return res.status(400).json({ ok: false, error: 'phone and message required' });
    const result = await sendSMS(phone, message.substring(0,160), type || 'manual');
    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Get SMS log (last 50)
app.get('/api/sms/log', async (req, res) => {
  try {
    let logs;
    if (dbConnected) logs = await SMSLog.find().sort({ createdAt: -1 }).limit(50);
    else logs = [...mem.sms].sort((a,b) => new Date(b.createdAt)-new Date(a.createdAt)).slice(0,50);
    res.json({ ok: true, logs });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/* === 7. WEATHER SMS BROADCAST ============================= */

app.post('/api/weather/broadcast', async (req, res) => {
  try {
    const { temp, rain, water, sprayAdvice } = req.body;
    let farmers = [];
    if (dbConnected) farmers = await Farmer.find({});
    else farmers = mem.farmers;

    let sent = 0;
    for (const f of farmers) {
      const msg = f.lang === 'ta'
        ? `வணக்கம்! இன்று ${temp}°C, மழை வாய்ப்பு ${rain}%. தண்ணீர்: ${water}L. ${sprayAdvice}`
        : `Vanakkam! Today ${temp}°C, rain ${rain}%. Water: ${water}L. ${sprayAdvice}`;
      await sendSMS(f.phone, msg.substring(0,160), 'weather');
      sent++;
    }
    res.json({ ok: true, sent });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/* ================================================================
   FEATURE 1: CHEMICAL RESISTANCE TRACKER
   - Log every spray with chemical name
   - After 3 uses of same chemical on same disease → resistance warning
   - District-level resistance map
================================================================ */

// Log a spray
app.post('/api/spray/log', async (req, res) => {
  try {
    const { phone, crop, disease, chemical, chemical_ta, dose, sprayDate, effective } = req.body;
    if (!phone || !crop || !disease || !chemical)
      return res.status(400).json({ ok: false, error: 'phone, crop, disease, chemical required' });

    const entry = { phone, crop, disease, chemical, chemical_ta:chemical_ta||'', dose:dose||'', sprayDate:sprayDate?new Date(sprayDate):new Date(), effective:effective||'unknown', createdAt:new Date() };

    if (dbConnected) await SprayLog.create(entry);
    else mem.sprays.push(entry);

    // Check resistance: same chemical used 3+ times on same disease in last 60 days
    const cutoff = new Date(Date.now() - 60*24*60*60*1000);
    let count = 0;
    if (dbConnected) {
      count = await SprayLog.countDocuments({ phone, disease, chemical, sprayDate: { $gte: cutoff } });
    } else {
      count = mem.sprays.filter(s => s.phone===phone && s.disease===disease && s.chemical===chemical && new Date(s.sprayDate)>=cutoff).length;
    }

    let warning = null;
    if (count >= 3) {
      const alternatives = getAlternativeChemicals(chemical);
      warning = {
        level: count >= 5 ? 'critical' : 'high',
        count,
        message_en: `⚠️ You have used ${chemical} ${count} times for ${disease}. Resistance likely! Switch to: ${alternatives.join(' or ')}.`,
        message_ta: `⚠️ ${chemical_ta||chemical} ${count} முறை பயன்படுத்தீர்கள். எதிர்ப்பு சக்தி உருவாகலாம்! மாற்று: ${alternatives.join(' அல்லது ')}.`,
        alternatives
      };
      // SMS warning to farmer
      if (phone) await sendSMS(phone, warning.message_en.substring(0,160), 'resistance');
    }

    res.json({ ok: true, logged: true, count, warning });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

// Get spray history + resistance analysis for a farmer
app.get('/api/spray/history/:phone', async (req, res) => {
  try {
    const { phone } = req.params;
    const cutoff = new Date(Date.now() - 90*24*60*60*1000); // last 90 days
    let sprays = [];
    if (dbConnected) {
      sprays = await SprayLog.find({ phone, sprayDate:{$gte:cutoff} }).sort({ sprayDate:-1 });
    } else {
      sprays = mem.sprays.filter(s => s.phone===phone && new Date(s.sprayDate)>=cutoff).sort((a,b)=>new Date(b.sprayDate)-new Date(a.sprayDate));
    }

    // Build resistance report per disease+chemical combo
    const resistanceMap = {};
    for (const s of sprays) {
      const key = `${s.disease}||${s.chemical}`;
      if (!resistanceMap[key]) resistanceMap[key] = { disease:s.disease, chemical:s.chemical, chemical_ta:s.chemical_ta, count:0, lastUsed:s.sprayDate, risk:'low' };
      resistanceMap[key].count++;
    }
    for (const k of Object.keys(resistanceMap)) {
      const c = resistanceMap[k].count;
      resistanceMap[k].risk = c >= 5 ? 'critical' : c >= 3 ? 'high' : c >= 2 ? 'medium' : 'low';
      resistanceMap[k].alternatives = getAlternativeChemicals(resistanceMap[k].chemical);
    }

    res.json({ ok:true, sprays, resistanceReport: Object.values(resistanceMap) });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

// Mark a spray as effective or not (farmer feedback after 5 days)
app.post('/api/spray/feedback', async (req, res) => {
  try {
    const { phone, disease, chemical, effective } = req.body;
    if (dbConnected) {
      await SprayLog.updateMany({ phone, disease, chemical }, { effective });
    } else {
      mem.sprays.forEach(s => { if(s.phone===phone && s.disease===disease && s.chemical===chemical) s.effective=effective; });
    }
    res.json({ ok:true });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

// District-level resistance heatmap
app.get('/api/spray/resistance-map', async (req, res) => {
  try {
    const cutoff = new Date(Date.now() - 60*24*60*60*1000);
    let sprays = [];
    if (dbConnected) sprays = await SprayLog.find({ sprayDate:{$gte:cutoff} });
    else sprays = mem.sprays.filter(s => new Date(s.sprayDate)>=cutoff);

    const map = {};
    for (const s of sprays) {
      const key = `${s.disease}||${s.chemical}`;
      if (!map[key]) map[key] = { disease:s.disease, chemical:s.chemical, totalUses:0, farmersAffected:new Set() };
      map[key].totalUses++;
      map[key].farmersAffected.add(s.phone);
    }
    const result = Object.values(map).map(m => ({
      disease: m.disease, chemical: m.chemical, totalUses: m.totalUses,
      farmersAffected: m.farmersAffected.size,
      resistanceRisk: m.totalUses > 20 ? 'high' : m.totalUses > 10 ? 'medium' : 'low'
    }));
    res.json({ ok:true, resistanceMap: result });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

function getAlternativeChemicals(chemical) {
  const alt = {
    'Mancozeb':      ['Propiconazole','Tricyclazole','Tebuconazole'],
    'Tricyclazole':  ['Azoxystrobin','Propiconazole','Carbendazim'],
    'Chlorothalonil':['Mancozeb','Tebuconazole','Hexaconazole'],
    'Tebuconazole':  ['Propiconazole','Mancozeb','Carbendazim'],
    'Propiconazole': ['Trifloxystrobin','Tebuconazole','Carbendazim'],
    'Carbendazim':   ['Thiophanate-methyl','Propiconazole','Mancozeb'],
  };
  return alt[chemical] || ['Neem oil (organic)','Consult agri officer'];
}

/* ================================================================
   FEATURE 2: LEAF PROGRESS TRACKER (Before vs After)
   - Save scan results over time for same farmer+crop
   - AI comparison: disease reduced / worsened / healed
   - Timeline visualization
================================================================ */

// Add a scan to progress timeline
app.post('/api/progress/scan', async (req, res) => {
  try {
    const { phone, crop, disease, confidence, severity, problem, note } = req.body;
    if (!phone || !crop) return res.status(400).json({ ok:false, error:'phone and crop required' });

    const scanEntry = { date:new Date(), confidence:confidence||0, severity:severity||'unknown', problem:problem||'', note:note||'' };

    let record;
    if (dbConnected) {
      record = await LeafProgress.findOne({ phone, crop, disease });
      if (record) {
        record.scans.push(scanEntry);
        if (record.scans.length > 10) record.scans = record.scans.slice(-10); // keep last 10
        await record.save();
      } else {
        record = await LeafProgress.create({ phone, crop, disease:disease||'', scans:[scanEntry] });
      }
    } else {
      record = mem.progress.find(p => p.phone===phone && p.crop===crop && p.disease===disease);
      if (record) { record.scans.push(scanEntry); }
      else { record = { phone, crop, disease:disease||'', scans:[scanEntry], createdAt:new Date() }; mem.progress.push(record); }
    }

    // Analyze trend
    const trend = analyzeProgressTrend(record.scans);
    res.json({ ok:true, trend, scans: record.scans });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

// Get full progress timeline for a farmer
app.get('/api/progress/:phone', async (req, res) => {
  try {
    const { phone } = req.params;
    let records = [];
    if (dbConnected) records = await LeafProgress.find({ phone }).sort({ createdAt:-1 });
    else records = mem.progress.filter(p => p.phone===phone);

    const enriched = records.map(r => ({
      crop: r.crop, disease: r.disease, scans: r.scans,
      trend: analyzeProgressTrend(r.scans),
      scanCount: r.scans.length
    }));
    res.json({ ok:true, records: enriched });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

function analyzeProgressTrend(scans) {
  if (!scans || scans.length < 2) return { status:'pending', message_en:'Scan again in 5 days to see progress.', message_ta:'5 நாள் பின் மீண்டும் ஸ்கேன் செய்யுங்கள்.', change: 0 };

  const severityScore = { healthy:0, low:1, medium:2, high:3, unknown:2 };
  const first = scans[0];
  const last  = scans[scans.length - 1];
  const firstScore = severityScore[first.severity] || 2;
  const lastScore  = severityScore[last.severity]  || 2;
  const change = firstScore - lastScore; // positive = improving

  // Also compare confidence if same disease
  const confChange = (last.confidence||0) - (first.confidence||0);

  let status, message_en, message_ta;
  if (last.severity === 'healthy' || lastScore === 0) {
    status = 'healed';
    message_en = `✅ Leaf healed! Treatment worked over ${scans.length} scans. Great job!`;
    message_ta = `✅ இலை குணமடைந்தது! சிகிச்சை வெற்றி. ${scans.length} ஸ்கேன்களில் முன்னேற்றம்.`;
  } else if (change > 0) {
    status = 'improving';
    message_en = `📈 Improving! Severity dropped from ${first.severity} to ${last.severity}. Continue treatment.`;
    message_ta = `📈 முன்னேற்றம்! ${first.severity} நிலையிலிருந்து ${last.severity}க்கு குறைந்தது. சிகிச்சை தொடருங்கள்.`;
  } else if (change < 0) {
    status = 'worsening';
    message_en = `📉 Worsening! Severity increased from ${first.severity} to ${last.severity}. Change your chemical — try ${getAlternativeChemicals(last.problem||'')[0]}.`;
    message_ta = `📉 நோய் அதிகரிக்கிறது! மருந்து மாற்றவும் — ${getAlternativeChemicals(last.problem||'')[0]} முயற்சிக்கவும்.`;
  } else {
    status = 'stable';
    message_en = `➡️ No change after ${scans.length} scans. Try switching to organic treatment or call 1800-180-1551.`;
    message_ta = `➡️ ${scans.length} ஸ்கேன்களுக்கு பின்னும் மாற்றம் இல்லை. இயற்கை முறை முயற்சிக்கவும் அல்லது 1800-180-1551 அழைக்கவும்.`;
  }
  return { status, message_en, message_ta, change, scans: scans.length, firstSeverity: first.severity, lastSeverity: last.severity };
}

/* ================================================================
   FEATURE 3: CROP STRESS EARLY WARNING SYSTEM
   - Predict disease conditions 2-3 days BEFORE symptoms appear
   - Based on epidemiology models + live weather
   - Proactive SMS alerts to all farmers
================================================================ */

// Get current stress prediction for a crop+location
app.get('/api/stress/predict', async (req, res) => {
  try {
    const lat  = parseFloat(req.query.lat)  || 9.92;
    const lon  = parseFloat(req.query.lon)  || 78.12;
    const crop = req.query.crop || 'tomato';

    // Fetch 3-day weather forecast
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&timezone=auto&forecast_days=3&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,relative_humidity_2m_max&hourly=relative_humidity_2m,temperature_2m`;
    let wx = null;
    try { wx = await axios.get(url).then(r => r.data); } catch(e) {}

    const predictions = generateStressPredictions(crop, wx);
    res.json({ ok:true, crop, predictions, weatherAvailable: !!wx });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

// Get all active stress alerts
app.get('/api/stress/alerts', async (req, res) => {
  try {
    const cutoff = new Date(Date.now() - 3*24*60*60*1000);
    let alerts = [];
    if (dbConnected) alerts = await StressAlert.find({ createdAt:{$gte:cutoff} }).sort({ createdAt:-1 }).limit(20);
    else alerts = mem.stress.filter(s => new Date(s.createdAt)>=cutoff);
    res.json({ ok:true, alerts });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

// Manually trigger stress check (also called by cron)
app.post('/api/stress/check', async (req, res) => {
  try {
    const results = await runStressCheck();
    res.json({ ok:true, alerts: results });
  } catch(err) { res.status(500).json({ ok:false, error:err.message }); }
});

function generateStressPredictions(crop, wx) {
  const predictions = [];
  // Use live weather if available, else use conservative defaults
  const avgHumidity = wx ? (() => { const h=wx.hourly.relative_humidity_2m.slice(0,72); return h.reduce((a,b)=>a+b,0)/h.length; })() : 72;
  const maxTemp     = wx ? Math.max(...wx.daily.temperature_2m_max) : 34;
  const minTemp     = wx ? Math.min(...wx.daily.temperature_2m_min) : 26;
  const rainDays    = wx ? wx.daily.precipitation_probability_max.filter(r=>r>50).length : 1;
  const rainMM      = wx ? wx.daily.precipitation_sum.reduce((a,b)=>a+b,0) : 8;

  // ── Blast / Blight risk (high humidity + moderate temp) ──────
  if ((crop === 'paddy' || crop === 'tomato') && avgHumidity >= 70 && maxTemp >= 28 && maxTemp <= 35) {
    const risk = avgHumidity >= 85 ? 'critical' : avgHumidity >= 78 ? 'high' : 'medium';
    const disease = crop === 'paddy' ? 'Rice blast' : 'Early blight';
    const disease_ta = crop === 'paddy' ? 'குலை நோய்' : 'இலை கருகல்';
    predictions.push({
      riskType: crop === 'paddy' ? 'blast' : 'blight',
      riskLevel: risk,
      disease, disease_ta,
      daysAhead: 2,
      message_en: `⚠️ ${disease} conditions forming! Humidity ${Math.round(avgHumidity)}%, Temp ${Math.round(maxTemp)}°C. Spray P. fluorescens NOW — before symptoms appear in ~2 days.`,
      message_ta: `⚠️ ${disease_ta} சூழல் உருவாகிறது! ஈரப்பதம் ${Math.round(avgHumidity)}%. 2 நாளுக்கு முன்பே சூடோமோனாஸ் தெளிக்கவும்.`,
      preventiveAction_en: crop === 'paddy' ? 'Spray P. fluorescens 10g/L or Tricyclazole 0.6g/L preventively.' : 'Spray Neem oil 3ml/L or Mancozeb 2g/L preventively.',
      preventiveAction_ta: crop === 'paddy' ? 'சூடோமோனாஸ் 10 கி/லி அல்லது டிரைசைக்ளசோல் 0.6 கி/லி தடுப்பு தெளிப்பு.' : 'வேப்ப எண்ணெய் 3 மிலி/லி அல்லது மேன்கோசெப் 2 கி/லி தடுப்பு தெளிப்பு.'
    });
  }

  // ── Thrips / Pest risk (hot + dry) ───────────────────────────
  if (maxTemp >= 35 && avgHumidity < 60 && rainDays === 0) {
    const riskCrops = { tomato:'Leaf curl (thrips)', chilli:'Leaf curl (thrips)', groundnut:'Rust' };
    const riskTa   = { tomato:'இலை சுருள் (இலைப்பேன்)', chilli:'இலை சுருள்', groundnut:'துரு நோய்' };
    if (riskCrops[crop]) {
      predictions.push({
        riskType: 'thrips',
        riskLevel: maxTemp >= 38 ? 'critical' : 'high',
        disease: riskCrops[crop], disease_ta: riskTa[crop],
        daysAhead: 3,
        message_en: `🌡️ Hot dry conditions (${Math.round(maxTemp)}°C, humidity ${Math.round(avgHumidity)}%) — ${riskCrops[crop]} risk HIGH in 3 days. Install yellow sticky traps now.`,
        message_ta: `🌡️ வெப்பம் (${Math.round(maxTemp)}°C, ஈரம் ${Math.round(avgHumidity)}%) — ${riskTa[crop]} அபாயம். இப்போதே மஞ்சள் பொறி வைக்கவும்.`,
        preventiveAction_en: 'Install yellow sticky traps. Spray Neem oil 3ml/L at 6 AM.',
        preventiveAction_ta: 'மஞ்சள் பொறி வைக்கவும். காலை 6 மணிக்கு வேப்ப எண்ணெய் 3 மிலி/லி தெளிக்கவும்.'
      });
    }
  }

  // ── Fungal (rain after dry) ───────────────────────────────────
  if (rainDays >= 2 && rainMM >= 10 && minTemp >= 22) {
    if (crop === 'groundnut' || crop === 'chilli') {
      predictions.push({
        riskType: 'rust',
        riskLevel: rainMM >= 20 ? 'high' : 'medium',
        disease: 'Rust / Anthracnose', disease_ta: 'துரு / ஆந்த்ராக்னோஸ்',
        daysAhead: 3,
        message_en: `🌧️ Rain ${Math.round(rainMM)}mm expected — Rust/Anthracnose risk in 3 days. Apply Tebuconazole 1ml/L or garlic-chilli spray preventively.`,
        message_ta: `🌧️ ${Math.round(rainMM)}மிமீ மழை எதிர்பார்க்கப்படுகிறது — துரு நோய் அபாயம். டெபுகோனசோல் 1 மிலி/லி தெளிக்கவும்.`,
        preventiveAction_en: 'Spray Tebuconazole 1ml/L or garlic-chilli extract before rain.',
        preventiveAction_ta: 'மழைக்கு முன்பு டெபுகோனசோல் 1 மிலி/லி தெளிக்கவும்.'
      });
    }
  }

  // ── Wilt (waterlogged soil after heavy rain) ──────────────────
  if (crop === 'banana' && rainMM >= 30) {
    predictions.push({
      riskType: 'wilt',
      riskLevel: 'high',
      disease: 'Panama wilt', disease_ta: 'வாடல் நோய்',
      daysAhead: 4,
      message_en: `💧 Heavy rain ${Math.round(rainMM)}mm — waterlogged soil risk. Panama wilt conditions in 4 days. Open drainage channels NOW.`,
      message_ta: `💧 கனமழை ${Math.round(rainMM)}மிமீ — வாடல் நோய் சூழல். இப்போதே வடிகால் திறக்கவும்.`,
      preventiveAction_en: 'Open all drainage channels. Apply Trichoderma 5g/L to soil.',
      preventiveAction_ta: 'வடிகால் திறக்கவும். மண்ணில் டிரைக்கோடெர்மா 5 கி/லி இடவும்.'
    });
  }

  // If no risk detected
  if (predictions.length === 0) {
    predictions.push({
      riskType: 'none',
      riskLevel: 'low',
      disease: 'No disease risk', disease_ta: 'நோய் அபாயம் இல்லை',
      daysAhead: 0,
      message_en: `✅ Weather conditions are safe for your ${crop} for the next 3 days.`,
      message_ta: `✅ அடுத்த 3 நாட்களுக்கு ${crop} பயிருக்கு வானிலை சாதகமாக உள்ளது.`,
      preventiveAction_en: 'Continue normal monitoring.',
      preventiveAction_ta: 'வழக்கமான கண்காணிப்பு தொடருங்கள்.'
    });
  }
  return predictions;
}

async function runStressCheck() {
  const cities = [
    { name:'Madurai', lat:9.92, lon:78.12 },
    { name:'Thanjavur', lat:10.79, lon:79.14 },
    { name:'Coimbatore', lat:11.0, lon:76.96 }
  ];
  const crops = ['paddy','tomato','groundnut','banana','chilli'];
  const newAlerts = [];

  for (const city of cities) {
    let wx = null;
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&timezone=auto&forecast_days=3&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,relative_humidity_2m_max&hourly=relative_humidity_2m,temperature_2m`;
      wx = await axios.get(url).then(r => r.data);
    } catch(e) {}

    for (const crop of crops) {
      const predictions = generateStressPredictions(crop, wx);
      for (const p of predictions) {
        if (p.riskLevel === 'low' || p.riskType === 'none') continue;
        const alertData = {
          village: city.name, crop, riskType: p.riskType, riskLevel: p.riskLevel,
          message_en: p.message_en, message_ta: p.message_ta,
          weatherData: wx ? { avgHumidity:'computed', city: city.name } : {},
          daysAhead: p.daysAhead, notified: false, createdAt: new Date()
        };
        if (dbConnected) await StressAlert.create(alertData).catch(()=>{});
        else mem.stress.push(alertData);
        newAlerts.push(alertData);

        // SMS all farmers growing this crop near this city
        let farmers = [];
        if (dbConnected) farmers = await Farmer.find({ crop });
        else farmers = mem.farmers.filter(f => f.crop === crop);
        for (const f of farmers) {
          const msg = f.lang === 'ta' ? p.message_ta.substring(0,160) : p.message_en.substring(0,160);
          await sendSMS(f.phone, msg, 'stress_alert');
        }
      }
    }
  }
  return newAlerts;
}

/* ─── CRON: Daily reminder check (runs at 7 AM every day) ── */
cron.schedule('0 7 * * *', async () => {
  console.log('⏰ Running daily reminder check...');
  try {
    const now = new Date();
    const tomorrow = new Date(now.getTime() + 24*60*60*1000);

    let due = [];
    if (dbConnected) {
      due = await Reminder.find({ sent: false, followUpDate: { $lte: tomorrow } });
    } else {
      due = mem.reminders.filter(r => !r.sent && new Date(r.followUpDate) <= tomorrow);
    }

    for (const r of due) {
      const msg = `🌿 Pasumai Kavalan follow-up: How is your ${r.disease||r.crop}? Open the app to scan your leaf again: http://localhost:8000 | Help: 1800-180-1551`;
      await sendSMS(r.phone, msg.substring(0,160), 'reminder');
      r.sent = true;
      if (dbConnected && r._id) await Reminder.updateOne({ _id: r._id }, { sent: true });
    }

    console.log(`✅ Sent ${due.length} follow-up reminders`);
  } catch(e) { console.error('Cron error:', e.message); }
});

/* ─── CRON: Stress early warning – runs every 6 hours ───── */
cron.schedule('0 */6 * * *', async () => {
  console.log('🧬 Running crop stress early warning check...');
  try {
    const alerts = await runStressCheck();
    console.log(`✅ Stress check done: ${alerts.length} alerts generated`);
  } catch(e) { console.error('Stress cron error:', e.message); }
});

/* ─── CRON: Daily weather SMS at 6 AM ───────────────────── */
cron.schedule('0 6 * * *', async () => {
  console.log('🌤️  Running daily weather SMS...');
  try {
    // Fetch weather for Madurai (default)
    const url = 'https://api.open-meteo.com/v1/forecast?latitude=9.92&longitude=78.12&timezone=auto&forecast_days=1&current=temperature_2m,relative_humidity_2m&daily=precipitation_probability_max,precipitation_sum,et0_fao_evapotranspiration';
    const wx = await axios.get(url).then(r => r.data).catch(() => null);
    if (!wx) return;

    const temp = Math.round(wx.current.temperature_2m);
    const rain = wx.daily.precipitation_probability_max[0] || 0;
    const et0  = wx.daily.et0_fao_evapotranspiration[0] || 5.2;
    const mm   = wx.daily.precipitation_sum[0] || 0;
    const water = Math.round(Math.max(0, et0 * 1.15 * 1 - mm) * 4047 / 100) * 100;
    const spray = rain < 30 ? 'Good to spray 6-9 AM.' : `Rain ${rain}%. Do not spray.`;

    let farmers = [];
    if (dbConnected) farmers = await Farmer.find({});
    else farmers = mem.farmers;

    for (const f of farmers) {
      const msg = f.lang === 'ta'
        ? `வணக்கம்! இன்று ${temp}°C, மழை ${rain}%. தண்ணீர்: ${water}L. ${rain<30?'தெளிக்கலாம்':'தெளிக்க வேண்டாம்.'}`
        : `Good morning! ${temp}°C, rain ${rain}%. Water: ${water}L. ${spray}`;
      await sendSMS(f.phone, msg.substring(0,160), 'weather');
    }
    console.log(`✅ Weather SMS sent to ${farmers.length} farmers`);
  } catch(e) { console.error('Weather cron error:', e.message); }
});

/* ─── Serve frontend static files ──────────────────────── */
const path = require('path');
const fs   = require('fs');
const FRONT = path.join(__dirname, '..');

app.get('/', (req, res) => res.sendFile(path.join(FRONT, 'index.html')));
app.use(express.static(FRONT));

/* ─── Start Server ──────────────────────────────────────── */
app.listen(PORT, () => {
  console.log(`\n🌿 Pasumai Kavalan Backend running on http://localhost:${PORT}`);
  console.log(`   DB:  ${process.env.MONGO_URI || 'mongodb://localhost:27017/pasumai'}`);
  console.log(`   SMS: ${process.env.MSG91_API_KEY ? 'MSG91 (real)' : 'Simulation mode (add MSG91_API_KEY for real SMS)'}`);
  console.log(`\n   Core API:`);
  console.log(`   GET  /api/health`);
  console.log(`   POST /api/farmer/register`);
  console.log(`   POST /api/outbreak/report  |  GET /api/outbreak/list`);
  console.log(`   POST /api/reminder/set     |  GET /api/reminder/:phone`);
  console.log(`   POST /api/ivr/result       |  POST /api/missedcall`);
  console.log(`   POST /api/sms/send         |  GET  /api/sms/log`);
  console.log(`\n   NEW — Unique Features:`);
  console.log(`   POST /api/spray/log        (Chemical Resistance Tracker)`);
  console.log(`   GET  /api/spray/history/:phone`);
  console.log(`   POST /api/spray/feedback`);
  console.log(`   GET  /api/spray/resistance-map`);
  console.log(`   POST /api/progress/scan    (Leaf Progress Tracker)`);
  console.log(`   GET  /api/progress/:phone`);
  console.log(`   GET  /api/stress/predict   (Crop Stress Early Warning)`);
  console.log(`   GET  /api/stress/alerts`);
  console.log(`   POST /api/stress/check\n`);
});
